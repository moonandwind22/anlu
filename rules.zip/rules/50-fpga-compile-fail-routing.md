# FPGA Compile-Fail Conditional Routing

当 fpga-compile-and-repair 内编译检查循环 3 轮未能通过时：

- 不要在主线程直接尝试修复 RTL/TB
- 下一步必须重新调用 `fpga-compile-and-repair`，并把 `sim/compile.log`、`sim/sim_result.json` 里的命令信息与相关源文件路径作为输入
- 如果是 TB 结构问题导致反复失败：调用 `fpga-tb-write` 重写 TB，再回到 `fpga-compile-and-repair`
- 如果是 DUT 逻辑问题：调用 `fpga-rtl-build` 修复 RTL，再回到 `fpga-compile-and-repair`
