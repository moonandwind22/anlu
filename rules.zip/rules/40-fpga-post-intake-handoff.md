# FPGA Post-Intake Handoff

如果本回合已经调用过 fpga-intake：
- 不要在主线程直接生成/修改 RTL 文件或 TB 文件，也不要直接跑仿真命令。
- 必须根据 fpga-intake 的 handoff_packet 选择下一步 skill：
  - 若 intake 判断下一步依赖模块拆分、顶层边界、协议初始化时序、CDC/复位策略、板级接口封装、黑盒 IP 包装或存储架构选择：优先调用 `fpga-architecture`
  - RTL 相关实现或改动：仅当接口边界、模块职责、初始化/CDC/缓存策略已经稳定时，调用 `fpga-rtl-build`
  - TB 源码生成：调用 `fpga-tb-write`
  - 编译检查：调用 `fpga-compile-and-repair`
  - 仿真运行 / VCD：调用 `fpga-sim-run`
- 若 RTL 阶段返回的结果暴露出命中 `rules/00-skill-routing.md` 中“协议时序敏感模块判定标准”的上游契约未冻结问题（例如端口/参数语义漂移、launch/sample edge 不明确、phase ordering 自相矛盾、片选生命周期或命令/响应边界靠猜测补全），不要在同层继续盲重试 `fpga-rtl-build`；应回退到 `fpga-architecture` 或补行为规格，再重新交接。
- 不要把 handoff_packet 中的推荐阶段全部自动执行。只执行用户本轮明确要求的阶段；其它阶段写入 manifest 的 `workflow_options` 作为可选下一步。
- 若 handoff_packet 不足以确定下一步：补充最少澄清问题或再次调用 fpga-intake 更新 handoff_packet。
