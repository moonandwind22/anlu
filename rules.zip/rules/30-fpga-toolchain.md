# FPGA Toolchain Policy

## 总原则

- 不要引导用户使用 brew/apt/yum 等系统包管理器安装 iverilog/gtkwave/verilator/ghdl/vivado 等工具。
- 优先使用 VSCode 插件内置的工具链与脚本。
- iverilog/vvp 工具位于插件目录的 `tools/iverilog/<platform>/` 下。

## 路径格式规则（重要）

**所有 Bash 命令中的路径必须使用相对路径或 `$PWD`，禁止硬编码绝对路径。**

- 插件在 Windows 上使用 Git Bash，但 CWD 可能是 Windows 格式
- **禁止硬编码的路径前缀**：`/d/`、`/c/`、`D:\`、`C:\`、`/cygdrive/` 等
- **正确做法**：使用 `$PWD` 动态获取当前目录

```bash
# ✅ 正确
ls -la rtl/*.v
grep 'pattern' "$PWD/sim/wave.vcd"
vvp_path="$(dirname $(which iverilog))/vvp"

# ❌ 错误
ls -la /d/iccoder-test/T1/sim/wave.vcd
cat D:\projects\foo\rtl\top.v
```

## iverilog 查找顺序（按优先级）

**第一步：优先从 PATH 查找**

1. 先执行 `iverilog --version` 验证 iverilog 是否在 PATH 中可用。
2. 如果成功，继续执行编译/仿真。

**第二步：备用路径（当 PATH 中找不到时）**

如果 `which iverilog` 返回空或 `iverilog --version` 失败：

1. 检查环境变量 `$ICCODER_TOOLS_ROOT`，如果存在且包含 `iverilog/bin/iverilog`，直接使用。
2. 在以下位置查找 `iverilog` 可执行文件：
   - `$ICCODER_TOOLS_ROOT/bin/iverilog`（首选）
   - `<extension_dir>/tools/iverilog/<platform>/bin/iverilog`

**第三步：报告阻塞（当所有路径都找不到时）**

如果以上两步都无法找到 iverilog：

1. **立即停止继续推进**，不要反复重试。
2. 输出明确的阻塞原因，说明 iverilog 工具未找到。
3. 提示用户检查插件安装是否完整。
4. **不要建议系统安装**（brew/apt/yum 等）。
5. 不要调用任何需要 iverilog 的 skill（如 fpga-compile-and-repair、fpga-sim-run）。

## vvp 路径解析

找到 iverilog 后，vvp 通常位于同一目录：

```bash
# 方法1：使用 dirname 解析
vvp_path="$(dirname $(which iverilog))/vvp"

# 方法2：使用 ICCODER_TOOLS_ROOT
vvp_path="$ICCODER_TOOLS_ROOT/bin/vvp"
```

## 编译脚本中的 iverilog 调用

`scripts/compile_iverilog.sh` 使用 `which iverilog` 查找。如果失败，脚本会输出错误并以 exit code 127 退出。

**不要在脚本失败后继续尝试其他路径**——工具缺失是阻塞条件，不是可恢复的错误。

## 禁止事项

- 不要执行或建议执行 `brew install ...`、`apt install ...`、`yum install ...` 等命令。
- 不要在找不到 iverilog 时反复重试或尝试不同的调用方式——工具缺失是明确的阻塞条件。
- 不要在 fpga-* skill 之前做"系统级工具链探测 + 安装建议"的分支决策；如需检查工具可用性，应在 fpga-intake 中记录为阻塞项。
