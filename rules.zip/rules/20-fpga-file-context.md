---
paths:
  - "**/*.{v,vh}"
  - "**/*.xdc"
  - "**/tb/**/*"
  - "**/sim/**/*"
---

# FPGA File-Context Rules

当对话已触达 HDL/约束/仿真相关文件（Read/Edit/Write 等）时，按以下规则增强执行稳定性：

1. 如果请求涉及修改 RTL：优先 fpga-rtl-build；如编译失败再转 fpga-compile-and-repair。
2. 如果请求涉及编译/语法问题：优先 fpga-compile-and-repair，并以工具输出为准。
3. 如果请求只涉及生成 TB 源码：fpga-tb-write。
4. 任何结论必须可回指到文件路径、日志或仿真结果；缺少证据就明确指出需要的输入，而不是臆测。
