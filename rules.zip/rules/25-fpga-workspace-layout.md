# FPGA Workspace Layout Contract

总原则：
- 源码目录只使用工程根目录的 `rtl/` 与 `tb/`：`rtl/` 放可综合 RTL 源码；`tb/` 放 TestBench 源码与 TB 相关 include。
- 仿真运行产物只使用工程根目录的 `sim/`：`sim/` 放仿真脚本、编译日志、运行日志、sim_result 与波形文件（VCD/FST）等。
- `doc/` 目录只用于"分析/规范/交接"工件（markdown/yaml/json 等），不要把 RTL/TB 源码或仿真产物放在 `doc/` 下。

## 路径格式规则（重要）

**所有 Bash 命令中的路径必须使用相对路径或 `$PWD`，禁止硬编码绝对路径。**

- 插件在 Windows 上使用 Git Bash，但 CWD 可能是 Windows 格式
- **禁止硬编码的路径前缀**：`/d/`、`/c/`、`D:\`、`C:\`、`/cygdrive/` 等
- **正确做法**：使用相对路径（`rtl/`、`tb/`、`sim/`）或 `$PWD` 动态获取

```bash
# 正确
ls -la rtl/*.v
grep 'pattern' sim/wave.vcd

# 错误
ls -la /d/iccoder-test/T1/rtl/*.v
```

必须遵守：
- 不要新建或写入 `doc/sim/` 作为 TB/仿真目录；不要把 TB 源码写到 `doc/sim/*.v`。
- 不要把可综合 RTL 源码写到 `doc/rtl/*.v`。`doc/rtl/` 仅允许保存 `notes.md`、`handoff_packet.md` 等"说明/交接"文件。
- TB 源码必须写入 `tb/`（例如 `tb/tb_top.v`、`tb/dut_inst.vh` 或项目既有 TB 文件）。
- 仿真脚本与产物必须写入 `sim/`（例如 `sim/run.sh`、`sim/compile.log`、`sim/sim.log`、`sim/sim_result.json`、`sim/wave.vcd`）。

兼容与迁移：
- 如果发现历史项目已经存在 `doc/rtl/*.v`、`doc/sim/*.v` 或根目录散落的 `*.vcd`/仿真可执行文件：不要继续沿用该布局生成新文件；后续新增/改动应按本规则落到 `rtl/`、`tb/`、`sim/`。如需迁移旧文件，应先输出迁移计划并等待用户确认。
