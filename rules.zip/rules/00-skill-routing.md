# Skills Routing Rules (FPGA)

总原则：

1. 优先使用最窄、产物最明确的 skill。
2. 需求模糊、缺少验收标准时先用 fpga-intake；需求明确（包含具体模块名、功能描述或已有代码参考）时直接跳到对应的实现类 skill。
3. 若用户明确指定某个 fpga-\* skill，且与请求一致，则直接调用该 skill。

## 用户可见输出边界（必须遵守）

- 路由和执行决策是内部实现细节。不要在面向用户的自然语言中说"调用 skill""使用 fpga-\*""SkillTool""内部能力名""底层模型"或 provider 名。
- 当需要执行 RTL、TB、编译、仿真、VCD、XDC 等阶段时，直接执行；进度文案只描述用户可理解的阶段，例如"正在生成 RTL""正在准备 TestBench""正在生成约束"。
- 如果用户追问内部机制，只回答 IC Coder 的公开定位：IC Coder 由自研 FPGA 领域专用大模型 IC Coder 模型和自研 IC Coder Agent 软件构成。

## 目录约定（所有 FPGA Skill 必须遵守）

**禁止在主线程直接创建目录；所有目录创建都在 Skill 内部完成。**

| 产物类型      | 路径                                                              | 规则                                                  |
| ------------- | ----------------------------------------------------------------- | ----------------------------------------------------- |
| RTL 源文件    | `rtl/*.v` / `rtl/*.sv`                                            | fpga-rtl-build 专用路径                               |
| TB 源文件     | `tb/*.v`                                                          | fpga-tb-write 专用路径（平铺在工程根目录 `tb/` 下）   |
| 规格/说明文档 | `doc/spec/`、`doc/rtl/`、`doc/<domain>/`                       | 只放 markdown/yaml/json 等说明、规格、交接文件        |
| 编译报告      | `doc/compile/`                                                   | fpga-compile-and-repair 诊断报告                      |
| 编译/仿真日志 | `sim/`                                                            | compile.log、sim.log、sim_result.json、波形等工具产物 |
| 编译报告      | `doc/compile/repair_report.md`                                   | fpga-compile-and-repair 修复失败报告                  |
| 约束文件      | `prj/constr/*.xdc` / `prj/constr/*.qsf` / `prj/constr/*.sdc` / `prj/constr/*.pin` | fpga-xdc-gen 专用路径，与 `doc/hw/`、`doc/spec/`、`doc/arch/` 等同属 `doc/` 领域子树 |
| 交接文档      | `doc/<domain>/handoff_packet.md`                                 | 仅复杂跨阶段任务需要时写；简单 RTL 生成默认不写给用户 |

> **注意**：可综合 RTL 源码必须写到 workspace 根目录的 `rtl/`。`doc/rtl/` 不得继续生成 `doc/rtl/*.v` 或 `doc/rtl/*.sv`；简单 RTL 任务的说明、假设和下一步建议统一写入 `doc/spec/behavior_spec.md` 与最终 manifest。

## RTL / TB / 编译 分流（必须遵守）

**核心原则**：RTL/TB 生成和重设计必须通过专用 skill；已有文件的**基础编辑**（注释、格式化、简单修复）可直接用 Edit/Write 工具，主 agent 本身具备基本的 Coding 能力。

**生成类行为（必须用 fork skill）**：
- 从零生成新 RTL 模块：必须通过 `fpga-rtl-build`（fork）
- 修改现有 RTL 的**设计意图**（重写状态机逻辑、改变接口协议、调整数据通路）：必须通过 `fpga-rtl-build`（fork）
- 从零生成新 TB：必须通过 `fpga-tb-write`（fork，按文件逐一调用）
- 重新生成 TB 以适配修改后的 RTL：必须通过 `fpga-tb-write`（fork，按文件逐一调用）

**编辑类行为（可直接工具，无需 fork）**：
- 为已有 RTL 文件添加注释、整理格式、添加空行/分隔符：对已有文件用 Edit/Write 工具直接编辑
- 修复 RTL 语法错误（如 always block 敏感信号缺失、位宽不匹配）：直接用 Edit/Write 工具修复
- 修改已有 RTL 中的参数值、常量定义、端口宽度：直接用 Edit/Write 工具修改
- 添加 assert/covergroup、代码格式化：直接用 Edit/Write 工具

**禁止**：不要在主线程直接生成完整的、可综合的 RTL 模块正文（必须有完整功能逻辑的状态机、数据通路、接口实现）。基础编辑工具仅用于注释、格式化和微小语法修复。

## Fork vs Inline 执行策略

`context: fork` 的 skill 会以 subagent 形式启动，skill 中配置的 `model` 字段会自动生效。

| Skill | 模式 |
|---|---|
| `fpga-rtl-build` | **fork** |
| `fpga-tb-write` | **fork** |
| `fpga-intake` | inline |
| `fpga-compile-and-repair` | inline |
| `fpga-sim-run` | inline |
| `fpga-xdc-gen` | inline |
| `fpga-architecture` | inline |
| `fpga-register-spec` | inline |
| `fpga-behavior-and-wave-plan` | inline |

## Fork 执行时的界面反馈（仅适用于 fork 技能）

以下规则仅适用于 `context: fork` 的 skill（fpga-rtl-build、fpga-tb-write）：

当一个 fork skill 执行时，必须以文本产物为唯一输出，不要在内部请求 Bash、Agent、Task、Write、Edit，也不要调用这些或其它命令执行工具。为此：

- fork skill 只返回可解析的 markdown 文件段落和 quality_report；主 Agent 负责解析 quality_report 并做最终质量判断
- 不要在 fork skill 内部调用 Bash、echo、$display、ls、wc、iverilog、verilator、yosys、vlog 或 vvp
- 如果信息不足或任务前提缺失，不要输出规划文本、分析过程或"下一步我将继续……"之类的收尾；改为输出 `needs_input` quality_report，明确缺失项
- fork skill 的成功标准不是"有 `## <相对路径>` 就算完成"，而是返回可解析的文件段落（`## <相对路径>` + 紧随其后的 fenced code block）且内容达到对应 skill 的质量门槛；仅返回说明性文本、规划文本、阶段性总结都不算成功产物
- 如果输出的是真实但未完成的半成品，quality_report 必须使用 `partial`，不得伪装成 `completed`
- **不要**在主 Agent 中等待 fork skill 完成后才显示任何内容；主 Agent 应透传流式文本进度

## Fork Skill 产物质量判断与写盘闸门

**绝对写盘前提**：正文含 stub 段落（`// ...`、`// ... omitted`、`// TODO`、`// FIXME`、`// TBD`、`// stub`、空块、注释掉的完整 always/case 块等）时，**无论 quality_report.status 是什么，一律不得写盘**，直接进入重复失败处理流程。Manifest status 只决定后续行为，不改变 stub 的禁止写盘判定。

fork skill 产出了 `## <相对路径>` 段落和 quality_report JSON，说明格式上合规，但主 Agent 仍需判断质量是否达到写盘门槛：

| quality_report.status | 正文含 stub | 主 Agent 行为 |
|----------------|------------|--------------|
| `completed` | 无 | 写盘，结束该阶段 |
| `completed` | 有 | 不写盘，进入重复失败处理流程 |
| `partial` | 有/无 | 不写盘，进入重复失败处理流程 |
| `needs_input` | 有/无 | 不写盘，收集缺失信息 |
| `error` 或无 quality_report | 有/无 | 不写盘，报告 `reason`，建议重新发起请求或更换 skill |

**禁止择优写盘**：不得从 `partial` / `needs_input` / 含 stub 的 `completed` 批次中挑"看起来还行"的单个文件写盘。质量判定以批次为单位。

**主 Agent 不得将"有 `## <path>` 段落"本身作为"写盘依据"，必须同时检查 status 和正文内容质量。**

## 重复失败处理

"连续失败"**仅限** fork skill 对同一任务连续 2 次返回"无内容"（没有任何 `##` 代码块，也没有 quality_report）。"有内容但质量差"（返回了代码块，但 status 不是 completed 或内容含 stub）不算失败，可继续重试。

重试时**不得**将首次 prompt 原文重发。必须先从上次输出中提取 stub 段落，再将补全指引注入 prompt。

### stub 提取规则（主 Agent 执行）

从上次 skill 输出中识别以下模式，视为 stub：
- 行内或独行的 `// ...`、`// ... omitted`、`// ... more code ...`、`// [N-M] omitted` 等省略标记
- 行内或独行的 `// TODO`、`// FIXME`、`// TBD`、`// stub`、`// to be implemented`、`// fill in`、`// placeholder`
- 注释掉的完整代码段（已注释的 `always`、`case`、`assign` 等）
- 仅有声明但 `begin...end` 内只有注释的空块

**提取方式**：将所有 stub 段落原文保留，拼接成一句描述，例如：
> "上次输出在以下位置缺少实现：axi_lite.v 第 47-89 行（写地址状态机）、第 103-115 行（读数据阶段）"

### 重试 prompt 构造规则

将以下结构化指令追加到原始 prompt 后（不要替换原始 prompt）：

```
补充实现指引：
- 上次输出在以下位置存在 stub 或未完成代码（必须用完整实现替换，禁止省略）：
  <粘贴上次所有 stub 段落>
- 禁止使用 "// ..."、"// omitted"、"// more code" 等省略写法
- 本次输出只需提供 `## <path>` 代码块（覆盖缺失部分即可），无需重复已完整的部分
- 如已有完整的 submodule 实例化代码，无需重写
```

### 重复失败处理表

| 连续失败次数 | 行为 |
|-------------|------|
| 第 1 次（有内容但质量差） | 不写盘，提取 stub，追加补全指引，重试 |
| 第 1 次（无内容） | 不写盘，可重试 |
| 第 2 次（连续有内容但质量差） | 停止自动重试，向用户说明质量问题 + 建议 |
| 第 2 次（连续无内容） | 停止自动重试，进入以下处理路径 |
| 3 次以上 | 一律停止，强制要求用户介入决策 |

停止重试后的处理路径：
1. 向用户说明失败情况（skill 无任何产物输出，或产物质量未达门槛）
2. 如果失败的是**编辑类任务**（添加注释、修复语法错误、修改参数等基础编辑），**直接用 Edit/Write 工具完成**，不要卡死
3. 建议拆解任务（如"先做 SPI master，再做 SD card ctrl"）
4. 建议补充约束（如提供顶层端口定义、更明确的接口时序）
5. 建议改用更上游 skill（如先走 `fpga-architecture` 形成模块划分）

## 路由表（按用户意图）

- 需求含混、缺验收、不知道从哪开始：**fpga-intake**（当且仅当需求模糊、缺少验收标准时）
- 需求**已明确**（如"写一个计数器"、"实现 AXI 模块"），且需要写代码的：
  - 包含 RTL 实现的：直接 `fpga-rtl-build`
  - 包含生成 TB 源码的：直接 `fpga-tb-write`（**按文件逐一调用**，一次只生成一个 TB 文件）
  - 同时包含 RTL + TB：先 `fpga-rtl-build`，再 `fpga-tb-write`
  - 包含仿真运行或 VCD 的：已有 RTL/TB 时调用 `fpga-sim-run`；缺 TB 时先把"生成 TB"作为可选项或按用户明确要求调用 `fpga-tb-write`
  - 包含 XDC、约束或管脚分配的：调用 `fpga-xdc-gen`；若缺硬件配置或管脚资料，`fpga-xdc-gen` 会输出 `needs_input` 并给出补全路径（prepare_hw → generate_top → run_xdc）；若 RTL 顶层没有板级端口但硬件信息已完备，也会提示建议生成板级 `top.v`
- **多模块/协议类任务必须在 RTL 之前先走 architecture**：涉及 2 个以上相互通信的子模块、需要协议初始化序列（如 SPI Flash init、SD 卡 init、UART bootloader）、涉及 CRC/包组装/握手/多时钟域数据通路、或顶层端口和子模块边界尚未定义时，应先 `fpga-architecture` 再 `fpga-rtl-build`。禁止在未完成架构设计时直接调用 `fpga-rtl-build` 生成整个系统的 RTL（会产生大量 stub 模块）。
- **RTL 生成按模块逐一调用**：`fpga-rtl-build` 一次调用只生成一个模块（一个 `## rtl/<module>.v` 代码块）。不要试图一次调用生成多个模块。architecture 输出的模块列表中每个模块单独调用一次 `fpga-rtl-build`，前一个模块写盘完成后再调用下一个。例如：5 个模块 → 5 次 `fpga-rtl-build` 调用，每次只聚焦一个模块。
- 以下中间技能**不是每个项目都需要**，只有当任务涉及相应复杂度时才触发：
  - 有**多模块拆分、总线接口、CDC 策略**等架构问题时：`fpga-architecture`
  - 有**寄存器映射、CPU 总线接口（AXI-Lite/APB）、控制面**时：`fpga-register-spec`
  - 有**行为规格、FSM 规则、不变量、波形检查点**时：`fpga-behavior-and-wave-plan`
  - 有**综合约束、引脚分配**时：`fpga-xdc-gen`
- 简单计数器/分频器/单模块/数据通路：直接 `fpga-rtl-build`，不需要中间技能
- 例如"使用 Verilog 语言设计一个 4 分频的分频电路"应直接进入 `fpga-rtl-build`，并使用合理默认端口与复位策略，同时在 notes/spec 中记录假设。
- **内部功能模块（ALU、FIFO、DMA、协议引擎等）生成后，`fpga-rtl-build` 可根据上下文判断是否附带生成 `rtl/top.v` 板级顶层封装**，该顶层（若生成）仅例化功能模块并连接板级 I/O 信号，不含业务逻辑。当 `top.v` 存在时，后续 XDC 约束可基于其端口进行管脚分配，但生成与否取决于当前调用的上下文判断，不作强制要求。

### 硬件准备与顶层引导

当用户表达了板级意图（提到 LED、KEY、按钮、时钟、约束、管脚分配、XDC、上板，或要求"把模块接到板子上"）但 `rtl/` 下没有板级顶层模块时，主 Agent 应主动判断：

1. **硬件信息已完备**（`doc/hw/extracted_facts.json` 或 `doc/hw/config.json` 中有管脚名、时钟、电气参数）：
   → 建议生成 `top.v` 作为板级入口。可通过 `fpga-rtl-build`（已知板级信号时）或 `fpga-architecture`（需要规划顶层结构时）完成。

2. **硬件信息未完备**（没有板级信号名、没有参考约束文件）：
   → 建议先走 `fpga-hw-manual-extraction` 提取硬件事实，再生成 `top.v`，再生成 XDC。这是自然的三步顺序，不要在没有板级信号名的情况下硬编 top.v。

3. **纯内部模块意图**（ALU、FIFO、协议引擎等，用户没有提板级操作）：
   → 不要主动建议生成 `top.v`，除非用户明确要求。

主 Agent 应具备足够的 FPGA 工作流常识，知道 XDC 依赖"顶层模块 + 硬件信息"两个前提条件。硬件信息不完备时，优先补信息而不是跳过或猜测。
- **编辑已有 RTL 文件**（添加注释、整理格式、修复语法错误、修改参数值）：直接用 Edit/Write 工具，不需要任何 skill，更不需要 fork。如果涉及重设计意图（如改写状态机逻辑、改变接口协议），才通过 `fpga-rtl-build`。

## 阶段可选策略（省算力默认，可选流程）

- 默认不生成 TB：用户只要求 RTL 时，完成 RTL 后停止，把 TB 作为 `workflow_options` 展示。
- 默认不运行编译检查：用户只要求生成代码时，不自动跑 iverilog，把编译检查作为 `workflow_options` 展示。
- RTL/TB 文件写入后不要额外运行 Bash、Read、ls、wc、iverilog、verilator、yosys 或 vlog 做"确认"；除非用户本轮明确要求对应阶段，否则只输出 manifest 并停止。
- 默认不运行仿真：只有用户明确要求"跑仿真/验证结果/执行 vvp"或选择前端按钮时，才运行仿真。
- 默认不生成 VCD：只有用户明确要求"VCD/波形/看波形"或选择前端按钮时，才启用 `ENABLE_VCD=1`。
- 默认不生成 XDC：只有用户明确要求"生成 XDC/约束/管脚分配/上板约束"或选择前端按钮时，才调用 `fpga-xdc-gen`。
- 如果用户要求"完整流程/完整验证/全套交付"，可按 RTL → TB → 编译检查 → 仿真运行 → XDC 推进；VCD 仍需用户明确要求波形，除非"完整验证"里明确包含波形证据。

## XDC / 约束

- XDC 生成必须读取 `doc/hw/config.json`。该文件由 VSCode 硬件配置面板保存，记录用户选择的板卡/芯片和上传资料元数据。
- 如果缺少芯片型号、目标厂商、管脚表、参考 XDC 或原理图，不要生成猜测性约束；输出 `needs_input` manifest，让前端展示需要补充的硬件资料。
- 所有约束相关文件（`.xdc`、`.qsf`、`.sdc`、`.pin` 及摘要/交接文档）统一放在 `prj/constr/`，与 `doc/hw/`、`doc/spec/` 等目录保持一致的领域组织结构。

## 快速工具型意图

- "只检查这个 .v 是否能过语法"：优先 fpga-compile-and-repair（只做 tool-first 编译检查，尽量不改代码）

## VCD 波形

- 默认流程不生成 VCD
- 用户明确要求时通过 `fpga-sim-run` 设置 `ENABLE_VCD=1`
