---
name: 约束生成
description: Generates or updates FPGA physical constraint files from confirmed RTL ports and extracted hardware facts. Use when board bring-up or constraint work needs XDC, UCF, PCF, QSF, SDC, or vendor-specific pin constraints without inventing pins, clocks, or IO standards.
allowed-tools: [Read, Grep, Glob, Edit, Write]
user-invocable: true
argument-hint: "<optional: top_module>"
arguments: [top_module]
when_to_use: 当 RTL 代码完成、需要生成或更新物理约束（管脚映射、电平标准、时钟约束、TCL 属性）时使用。本 Skill 为可选步骤，在 RTL 功能验证完成后按需调用。
version: "0.2.1"
---

# XDC / Constraint File Generation

Generate or update physical constraints from RTL plus the three-core hardware facts produced by `fpga-hw-manual-extraction`.

## Use this skill when

- The user explicitly asks for XDC, constraints, pin assignment, or board bring-up constraints.
- RTL is ready and physical constraints need to be generated or updated.
- The workflow reaches the optional constraint-generation stage after hardware facts are already extracted.

## Execution mode

- This is an inline skill. Read project files and write artifacts directly in the workspace.
- Use `Write` and `Edit` for `prj/constr/` artifacts.
- Do not switch to fork-style text-only artifact output for normal execution.

## Boundaries

- This skill is optional.
- Use `doc/hw/extracted_facts.json` as the primary fact source, not the original hardware documents.
- Treat output structure as template-aware, not fixed-format.
- Discover user-provided constraint templates with Glob (e.g. `**/*.xdc`, `**/*.qsf`, `**/*.sdc`, `**/*.ucf`) rather than hardcoding a specific directory path — VSCode extensions may place uploaded files in different locations depending on the upload flow. After discovery, filter candidates by vendor, board family, chip device, and naming pattern.
- Do not invent package pins, IO standards, clocks, reset polarity, bank voltage, or timing numbers.
- 不要编造管脚、电平标准、时钟、复位极性、Bank 电压或时序参数；缺资料时输出 `needs_input`。
- If `extracted_facts.json` is `needs_input`, stop after writing `prj/constr/missing_info.md`.
- If `extracted_facts.json` is `partial`, generate constraints only for confirmed facts and annotate every gap inline.
- Write all constraint-related artifacts under `prj/constr/`.

## Inputs

Prefer sources in this order:

1. `doc/hw/extracted_facts.json`
   - `pin_map`
   - `clock_facts`
   - `electrical_facts`
2. Board configuration JSON such as `doc/hw/config.json` for vendor, chip device, board name, and toolchain context
3. User-uploaded constraint templates and hardware attachments — discover with Glob (`**/*.xdc`, `**/*.qsf`, `**/*.sdc`, `**/*.ucf`, `**/*.pcf`, `**/*.pin`) rather than assuming a fixed directory; filter discovered files by metadata or naming convention
4. `doc/intake/summary.md` and `doc/intake/handoff_packet.md`
5. `rtl/`
6. Other hardware references only when a fact is missing from `extracted_facts.json`

## Template handling

When a user-provided constraint template is needed:

- Use Glob to discover constraint file candidates in the workspace (`**/*.xdc`, `**/*.qsf`, `**/*.sdc`, `**/*.ucf`, `**/*.pcf`, `**/*.pin`) before falling back to vendor-default generation.
- Filter candidates by vendor, board family, chip device, naming pattern, and explicit board-configuration metadata.
- Match templates by vendor, board family, chip device, naming pattern, and explicit board-configuration metadata.
- If multiple templates match, prefer the most specific one.
- If a usable template is found, preserve its layout, command style, section ordering, comments, naming conventions, and organization-specific wrappers.
- If no template matches, fall back to vendor-default constraint generation.

## Workflow

1. Read `doc/hw/extracted_facts.json` first.
2. Check its `status`:
   - `complete`: proceed normally.
   - `partial`: proceed with confirmed facts and annotate every gap.
   - `needs_input`: write `prj/constr/missing_info.md` and stop without writing the primary constraint file.
3. Read board configuration JSON to confirm vendor, chip device, and toolchain.
4. Discover constraint template candidates with Glob before any vendor-default fallback.
5. Read `rtl/` files to identify top-level ports and bit widths.
6. **Check whether the RTL top has board-level ports.**
   Evaluate what board-level signal names are available from context:
   - If the RTL top already has board-facing ports (LED/KEY/clock/reset pins): proceed to step 7.
   - If the RTL top has only internal signals but `doc/hw/extracted_facts.json` or
     `doc/hw/config.json` contains board signal names (pin_map, clock_facts, electrical_facts):
     Write `prj/constr/top_module_needed.md` explaining that a board-level `top` module
     is required to bridge the internal module ports to board signals. Return with a
     manifest suggestion to generate `top.v` via `fpga-rtl-build` using the known board
     signal names as connection targets. Do not block — suggest next action.
   - If the RTL top has only internal signals AND no board signal names are available
     in `extracted_facts.json` or `config.json`:
     Write `prj/constr/missing_hw_info.md` explaining that board signal names are needed
     before `top.v` can be generated. Return with a manifest suggestion pointing to
     `fpga-hw-manual-extraction` as the appropriate first step to extract hardware facts,
     followed by `top.v` generation, then XDC.
7. Map RTL ports to `pin_map` and `electrical_facts` using board-level signal names.
8. If a needed fact is missing in `extracted_facts.json`, consult other hardware references only if they are available.
9. Generate or adapt the constraint file using confirmed facts.
10. Write the primary constraint file plus supporting summaries directly into the workspace.

## Generation rules

- Adapt a matched template instead of emitting a fixed-format file when a usable template exists.
- Preserve non-fact-bearing template content unless it conflicts with confirmed hardware facts.
- Handle `evidence_kind` as follows:
  - `explicit`: use the value directly
  - `derived`: use the derived value
  - `fallback`: include available electrical evidence as a comment and write `UNKNOWN` for IOSTANDARD
  - missing with no source: write `TODO` and reference the gap
- Preserve board-level names; do not rename them to guessed RTL names.

## Output placement

- **Vivado (Xilinx)**: `prj/constr/top.xdc`
- **Quartus (Intel)**: `prj/constr/top.qsf` and/or `prj/constr/top.sdc`
- **Tang Dynasty (Anlogic)**: `prj/constr/top.xdc`
- **Gowin**: `prj/constr/top.pin` and/or `prj/constr/top.sdc`

## Required constraint content

Include applicable sections such as:

- `create_clock`
- `create_generated_clock`
- `set_input_delay` / `set_output_delay`
- `set_property PACKAGE_PIN` / `set_property IOSTANDARD`
- `set_location` / `set_io`
- `set_false_path` / `set_max_delay`
- `set_clock_groups`

If the matched template already contains organization-specific wrappers, helper commands, or section headers, preserve them.

## Output artifacts

- `prj/constr/top.xdc` or vendor-specific equivalent
- `prj/constr/pin_summary.md`
- `prj/constr/handoff_packet.md`
- `prj/constr/missing_info.md` only when `status: needs_input`

`prj/constr/pin_summary.md` must list each RTL top port, mapped pin, IO standard, and `source_ref`. Record fallback or missing gaps explicitly. If a template was used, record which template matched and why.

`prj/constr/handoff_packet.md` must record next steps, artifact paths, and whether generation was template-driven or vendor-default.

These artifacts must be written to the workspace during normal execution.

## Completion rules

The result is complete when:

- Every top-level port with a confirmed pin mapping is mapped to a physical pin.
- Every fallback or missing electrical fact is annotated explicitly instead of silently invented.
- Confirmed primary clock domains have corresponding clock and reset constraints where applicable.
- If a matching template was discovered via Glob, the generated file follows that template's layout and conventions.
- The output is syntactically valid for the target vendor toolchain.

## Missing-data behavior

| `extracted_facts.json` status | Action |
|---|---|
| `complete` | Proceed normally |
| `partial` | Generate constraints for confirmed facts and annotate every gap inline |
| `needs_input` | Write `prj/constr/missing_info.md` and do not write the primary constraint file |
| top module has no board-level ports | Write `prj/constr/missing_top_module.md` and stop without writing the primary constraint file |

When `partial`, annotate each gap with:

- the signal name
- the missing fact type
- the `source_ref` when available, otherwise `no source found`
- `UNKNOWN` for missing IOSTANDARD or `TODO` for missing pin/clock values

## Manifest next actions

When stopping due to missing hardware information or missing board-level top, include these suggested next steps in the final manifest's `workflow_options` (do not write them in natural language prose):

```json
{
  "workflow_options": [
    {
      "id": "prepare_hw",
      "label": "准备硬件信息",
      "description": "提取板级管脚、时钟和电气参数，为 top.v 生成和 XDC 铺底。",
      "prompt": "请读取用户上传的板卡手册、原理图或参考约束文件，提取 FPGA 项目的管脚映射、时钟参数和电气参数。"
    },
    {
      "id": "generate_top",
      "label": "生成板级顶层",
      "description": "在已知板级信号的情况下，生成连接内部模块到 FPGA 引脚的 top.v。",
      "prompt": "请生成板级顶层模块 rtl/top.v，用已知的板级信号（LED、KEY、时钟等）连接内部模块。"
    },
    {
      "id": "run_xdc",
      "label": "生成 XDC 约束",
      "description": "在 top.v 和硬件参数完备后，生成 FPGA 物理约束文件。",
      "prompt": "请基于 top.v 和提取的硬件参数，生成 XDC 物理约束文件。"
    }
  ]
}
```

Show all three options as a sequence when both hardware info and top module are missing. Show only `generate_top` + `run_xdc` when hardware info is available but no top module exists. Show nothing when XDC generation succeeds.

Example:

```tcl
# TODO [partial] signal: TXD  io_standard: UNKNOWN
# source: doc/hw/refs/board_manual.pdf §3.4  (bank_voltage=3.3V confirmed, IOSTANDARD not specified)
set_property IOSTANDARD UNKNOWN [get_ports TXD]
```

## Artifact manifest

When constraints are generated, include:

- the primary constraint file as `kind: "constraint"` and `role: "primary"`
- `prj/constr/pin_summary.md`
- `prj/constr/handoff_packet.md`
- suggested validation commands marked `not_run` unless actually executed
- checks for unmapped ports, clock-constraint coverage, evidence distribution, missing requirements, and matched template provenance

When `status: needs_input`, include:

- `"status": "needs_input"`
- `prj/constr/missing_info.md` as the primary artifact
- a blocked check explaining that `fpga-hw-manual-extraction` must complete first
- next actions that point back to hardware-fact extraction

When the RTL top has no board-level ports, include:

- `"status": "needs_input"`
- `prj/constr/missing_top_module.md` as the primary artifact
- a check explaining that a board-level `top` module is required (instantiating the internal module and connecting board-level signals)
- next actions that point to creating or identifying the board-level `top` module

## Vivado handoff

For Xilinx/Vivado targets, include the suggested import-command shape in `prj/constr/handoff_packet.md`, but do not execute Vivado from this skill:

```tcl
read_verilog [glob ./rtl/*.v]
read_xdc ./prj/constr/top.xdc
synth_design -top <top_module> -part <chip_device>
```
