# TB 生成交接文档

## Read First

- `tb/tb_top.v` — TB top module
- `tb/dut_inst.vh` — DUT instantiation
- `tb/scenario_matrix.md` — scenario coverage

## Compile Entry (for fpga-compile-and-repair)

```
iverilog -g2012 -Wall -I tb -I rtl -s tb_top [-DDUT_MODULE=<module_name>] \
    $(find rtl tb -name "*.v" | sort)
```

Where:
- `tb_top` is the TB top module name (matches `module tb_top;`)
- `-DDUT_MODULE=<module_name>` overrides the `DUT_MODULE` macro if the RTL module name differs from `example_module`
- All `.v` files under `rtl/` and `tb/` are auto-discovered; if files need a specific order, list them explicitly

## DUT Information

| Field | Value |
| --- | --- |
| RTL Module | TODO: fill in module name |
| Clock | TODO: fill in frequency (e.g. 50MHz) |
| Reset | TODO: fill in (e.g. async low-active) |
| Parameters | TODO: list all parameters and their values |

## Optional Next Stages

- Compile check: `fpga-compile-and-repair`
- Simulation run: `fpga-sim-run` with `RUN_SIM=1`
- VCD waveform: `fpga-sim-run` with `RUN_SIM=1 ENABLE_VCD=1`

## Open Risks

| Risk | Impact | Mitigation |

## Stop Conditions For Next Skill

- If compile fails: `fpga-compile-and-repair` will fix TB syntax and retry
- If simulation fails: route diagnostics to `fpga-rtl-build` for RTL logic issues or `fpga-tb-write` for TB expectation issues
- If DUT ports are wrong: route back to `fpga-rtl-build`
