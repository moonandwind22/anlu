#!/usr/bin/env bash
set -euo pipefail

mkdir -p sim

# Find iverilog: try PATH first, then ICCODER_TOOLS_ROOT fallback
find_iverilog() {
  # Try PATH first
  if iverilog_path="$(which iverilog 2>/dev/null)" && [[ -x "$iverilog_path" ]]; then
    echo "$iverilog_path"
    return 0
  fi

  # Fallback to ICCODER_TOOLS_ROOT
  if [[ -n "${ICCODER_TOOLS_ROOT:-}" ]]; then
    candidate="$ICCODER_TOOLS_ROOT/bin/iverilog"
    if [[ -x "$candidate" ]]; then
      echo "$candidate"
      return 0
    fi
  fi

  return 1
}

iverilog_path="$(find_iverilog)" || {
  echo "iverilog not found. Tried: PATH and \$ICCODER_TOOLS_ROOT/bin/iverilog" >&2
  echo "Ensure the IC Coder VSCode extension is properly installed." >&2
  exit 127
}

if [[ ! -x "$iverilog_path" ]]; then
  echo "iverilog is not executable: $iverilog_path" >&2
  exit 127
fi

tb_top_module="${TB_TOP_MODULE:-tb_top}"
dut_top_module="${DUT_TOP_MODULE:-}"
RUN_SIM="${RUN_SIM:-0}"
ENABLE_VCD="${ENABLE_VCD:-0}"

if [[ "${ENABLE_VCD}" == "1" ]]; then
  RUN_SIM="1"
fi

vvp_path=""
if [[ "${RUN_SIM}" == "1" ]]; then
  vvp_path="$(dirname "$iverilog_path")/vvp"
  if [[ ! -x "$vvp_path" ]]; then
    echo "vvp is not executable: $vvp_path" >&2
    exit 127
  fi
fi

files=()
while IFS= read -r f; do files+=("$f"); done < <(find rtl tb -type f \( -name "*.v" -o -name "*.sv" \) 2>/dev/null | sort || true)

if [[ ${#files[@]} -eq 0 ]]; then
  echo "No RTL/TB sources found under rtl/ or tb/" >&2
  exit 2
fi

compile_log="sim/compile.log"
sim_log="sim/sim.log"
out_vvp="sim/${tb_top_module}.vvp"
sim_result="sim/sim_result.json"
first_fail_compile_log="sim/compile.fail.log"
vcd_path="sim/wave.vcd"

compile_cmd=("$iverilog_path" -g2012 -Wall -I tb -I rtl -s "${tb_top_module}")
if [[ -n "${dut_top_module}" ]]; then
  compile_cmd+=("-DDUT_MODULE=${dut_top_module}")
fi

if [[ "${RUN_SIM}" == "1" ]]; then
  compile_cmd+=("-o" "${out_vvp}")
else
  compile_cmd+=("-tnull")
fi
compile_cmd+=("${files[@]}")

set +e
"${compile_cmd[@]}" >"${compile_log}" 2>&1
compile_rc=$?
set -e

if [[ ${compile_rc} -ne 0 ]]; then
  if [[ ! -f "${first_fail_compile_log}" ]]; then
    cp "${compile_log}" "${first_fail_compile_log}" 2>/dev/null || true
  fi
  vvp_json="null"
  if [[ -n "${vvp_path}" ]]; then
    vvp_json="\"${vvp_path}\""
  fi
  cat >"${sim_result}" <<JSON
{
  "status": "COMPILE_FAIL",
  "had_compile_fail": true,
  "compile_exit_code": ${compile_rc},
  "sim_exit_code": null,
  "iverilog": "${iverilog_path}",
  "vvp": ${vvp_json},
  "command": "${compile_cmd[*]}",
  "compile_log": "${compile_log}",
  "first_fail_compile_log": "${first_fail_compile_log}",
  "sim_log": null,
  "vcd_generated": false,
  "vcd_path": null
}
JSON
  cat "${compile_log}" >&2
  exit "${compile_rc}"
fi

if [[ "${RUN_SIM}" != "1" ]]; then
  cat >"${sim_result}" <<JSON
{
  "status": "COMPILE_PASS",
  "had_compile_fail": false,
  "compile_exit_code": 0,
  "sim_exit_code": null,
  "iverilog": "${iverilog_path}",
  "vvp": null,
  "command": "${compile_cmd[*]}",
  "compile_log": "${compile_log}",
  "first_fail_compile_log": null,
  "sim_log": null,
  "vcd_generated": false,
  "vcd_path": null
}
JSON
  echo "COMPILE_PASS"
  exit 0
fi

runtime_vvp="${out_vvp}"
first_line="$(head -n 1 "${out_vvp}" || true)"
if [[ "${first_line}" == '#!'* ]]; then
  runtime_vvp="${out_vvp}.no_shebang"
  tail -n +2 "${out_vvp}" >"${runtime_vvp}"
  chmod +x "${runtime_vvp}" || true
fi

set +e
if [[ "${ENABLE_VCD}" == "1" ]]; then
  "${vvp_path}" "${runtime_vvp}" "+VCD=${vcd_path}" 2>&1 | tee "${sim_log}"
else
  "${vvp_path}" "${runtime_vvp}" 2>&1 | tee "${sim_log}"
fi
sim_rc=${PIPESTATUS[0]}
set -e

status="PASS"
if [[ ${sim_rc} -ne 0 ]]; then
  status="FAIL"
fi

vcd_generated="false"
vcd_json="null"
if [[ "${ENABLE_VCD}" == "1" && -f "${vcd_path}" ]]; then
  vcd_generated="true"
  vcd_json="\"${vcd_path}\""
fi

cat >"${sim_result}" <<JSON
{
  "status": "${status}",
  "had_compile_fail": false,
  "compile_exit_code": 0,
  "sim_exit_code": ${sim_rc},
  "iverilog": "${iverilog_path}",
  "vvp": "${vvp_path}",
  "command": "${compile_cmd[*]}",
  "compile_log": "${compile_log}",
  "first_fail_compile_log": null,
  "sim_log": "${sim_log}",
  "vcd_generated": ${vcd_generated},
  "vcd_path": ${vcd_json}
}
JSON

exit "${sim_rc}"
