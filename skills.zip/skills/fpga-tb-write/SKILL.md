---
name: TestBench生成
description: 当需要生成/维护自检 TestBench 源码时使用。不执行编译与仿真。生成后交给 fpga-compile-and-repair 做编译检查。
allowed-tools: [Read, Grep, Glob, Write, Edit]
user-invocable: true
argument-hint: "<optional: top_module>"
arguments: [top_module]
when_to_use: 当用户明确要求生成 TestBench/验证用例时使用。
model: iccoder-fpga
version: "0.1.0"
context: fork
---

# TB Write

Generate self-checking TestBench source files. Do not compile, run, or verify simulation here.

## Boundaries

- Generate TB source only. Compilation → `fpga-compile-and-repair`. Simulation/VCD → `fpga-sim-run`.
- Do NOT call `Bash`, `Agent`, or `Task` tools. `Bash` belongs to compile/sim skills; `Agent` / `Task` would nest a hidden subagent whose tool calls the user cannot see. `Write` and `Edit` are available — see "Output Format" below.
- A TB must produce an explicit PASS/FAIL result from the simulation runtime.
- Directory contract: TB sources under `tb/`, sim scripts under `sim/`. Never under `doc/sim/`.
- Do not attempt to fix RTL/TB syntax errors here — use `fpga-compile-and-repair`.

### HARD GATE — files must land on disk (non-negotiable)

**A response that only contains prose like "TestBench 已生成完成" or `## tb/tb_top.v` code blocks WITHOUT actually calling the `Write` tool is a FAILURE, even if the trailing `quality_report` claims `status: "completed"`.**

Concretely:

- Every artifact listed in "Output Artifacts" below MUST be created with a `Write` tool call. Inline code blocks alone do not satisfy this requirement — the workspace scanner only sees files that exist on disk.
- The trailing `## fpga-tb-write:quality_report` JSON block MUST list each file that was written in `stub_details` if it is incomplete, and MUST set `status: "partial"` if any required artifact is missing from disk.
- Before emitting `quality_report`, run `Glob` to verify every required file actually exists in the workspace. If any required file is missing, set `status: "partial"` with `missing_files` filled in (and write the missing files before retrying the verification step).
- The `inline ## <path> code block` style documented in "Output Format" is **only** allowed for files that already exist on disk in this same call and are being **edited** (e.g. modifying an existing `tb/scenario_matrix.md`). For files that are being created from scratch, the only acceptable mechanism is the `Write` tool.
- Do NOT end your response with a textual summary that implies success ("TestBench 已生成完成", "All done") unless every required file is verifiably on disk. The user trusts disk state, not your prose.

Failure modes this guard prevents:

1. Model emits `## tb/tb_top.v` code block + `quality_report: completed`, no `Write` call → user sees "完成" in chat but `tb/` directory is empty.
2. Model emits only an assistant message describing what would be in the TB files → chatProvider sees `quality_report: completed` but no file diff → silent data loss.
3. Model partial-completes (writes `tb/tb_top.v` but not `tb/dut_inst.vh`) → must report `status: "partial"` with the missing file in `stub_details`, not `completed`.

- The skill runs in a fork subagent, but the subagent has access to the same `Write` / `Edit` tools as the main agent. The primary output mechanism is `Write` / `Edit` tool calls — see HARD GATE above for why prose and inline code blocks alone are insufficient.
- After TB files land, the main agent composes a Chinese-language user-facing summary. Common next steps the summary may mention (the main agent decides, do not output these literally):
  - 编译检查：跑一下当前的 RTL 和 TestBench 的语法检查
  - 运行仿真：跑当前 TestBench 仿真
  - 生成 VCD：跑当前 TestBench 并生成 VCD 波形文件
  These are just next-step hints for the main agent's summary; the skill itself does not emit manifest or option-list JSON.

## Context Derivation (Priority — stop at first hit)

1. `doc/intake/handoff_packet.md` → full task brief
2. `doc/arch/interface_contract.yaml` / `connection_matrix.md` → port contracts, clock domains, reset strategy
3. `doc/spec/behavior_spec.md` / `scenario_matrix.md` → test plan
4. **Direct invocation** → read RTL source files (`rtl/*.v`) directly. Do not refuse or ask for clarification. If no RTL exists, output `status: "needs_input"` with `"missing_inputs": ["RTL source file not found"]`.

## Input Artifacts (Priority order)

1. `doc/hw/config.json` — chip, vendor (read first)
2. `doc/intake/summary.md`, `handoff_packet.md`
3. `doc/spec/behavior_spec.md`, `scenario_matrix.md`
4. `doc/arch/interface_contract.yaml`, `rtl/top_skeleton.v`
5. Existing RTL sources (`rtl/`), prior TB, sim scripts/logs

## Workflow

### Step 0 — Read RTL source first (non-negotiable)

**Do NOT generate any TB code before completing this step.**

1. Find the RTL file: use `Glob` to locate `rtl/*.v` or `rtl/*.sv`.
2. Read the RTL module declaration line by line. Extract:
   - Exact module name (case-sensitive)
   - Every port: **name**, **direction** (`input`/`output`), **width** (e.g. `[31:0]` or absent for 1-bit)
   - Every `parameter` (not `localparam`): name and default value
   - Every `localparam`: name and value (for reference, cannot override)
3. If no RTL file exists: output `status: "needs_input"` with `"missing_inputs": ["RTL source file not found in rtl/"]`.
4. If the RTL uses AXI, Avalon, or other standard bus: also read `references/tb_selfcheck_patterns.md` before generating bus-specific stimulus.

### Step 1 — Read context

Read behavior spec, RTL sources, and existing sim scripts. Note clock frequency, reset polarity, key protocol signals.

### Step 2 — Plan TB structure

Identify the smallest set of TB files. Understand from the RTL:

- Clock and reset signals
- All port names, widths, directions
- Protocol (valid/ready, handshakes)
- Key internal state observable via outputs

### Step 3 — Generate `tb/dut_inst.vh`

Instantiate the DUT with **exact port mapping** from the RTL declaration:

- Use `.PARAM_NAME(value)` at instantiation for `parameter` values
- If the RTL uses `localparam`: accept the fixed value, do NOT try to override
- Never use `defparam` before instantiation
- Extract parameter/localparam values from RTL source — do not invent values

### Step 4 — Generate `tb/tb_top.v`

- Clock: **always `#(CLK_PERIOD / 2)` form**, never `forever #...` inside `always`, never `always begin ... end`
- Clock formula: `parameter CLK_PERIOD = 1_000_000_000 / CLK_FREQ` (ns)
- Reset: assert `rst_n=0`, wait N cycles, release `rst_n=1`
- Timeout watchdog: `#TIMEOUT_CYCLES $fatal`
- DUT instantiation via `include "dut_inst.vh"`
- Driver: **wait for clock cycles**, not raw time units — `repeat (N) @(posedge clk)` preferred
- Checker: observe output signals on clock edges, compare with `!==`
- PASS/FAIL: `$display("PASS")` or `$display("FAIL errors=%0d", error_count)` then `$finish`
- **No stub language**: no `// ...`, `// TODO`, `// FIXME`, `// stub`

### Step 5 — Generate `tb/scenario_matrix.md`

- Each row: concrete stimulus description (not placeholder)
- Scenario names specific (e.g. `led_oneshot` not `test1`)
- For a simple module: 2-3 rows (reset_smoke + nominal + boundary) sufficient
- No empty table with only header row

### Step 6 — Generate `sim/run.sh` (optional)

Default to compile-only. Only run `vvp` when `RUN_SIM=1` is set. VCD off unless `ENABLE_VCD=1`.

### Step 7 — Self-check (mandatory before quality_report)

**Run this gate before emitting the trailing `quality_report` JSON block. If any check fails, fix the underlying issue (typically: actually call `Write`) and re-run before responding.**

1. Run `Glob` to list every file under `tb/` and `sim/` (created or updated in this call).
2. Cross-check against "Output Artifacts" below. Each required file MUST appear in the Glob output.
3. For each file in the Glob output, run `Read` (or re-open the file via `Glob` + size) to confirm it has **non-trivial content**:
   - Verilog file: must contain real RTL/TB code, not `// TODO` / `// stub` / `// ...` placeholders. Empty files or single-line placeholder files count as failure.
   - `scenario_matrix.md`: must have at least 2 concrete scenario rows beyond the header row.
   - `run.sh`: must contain a `iverilog` or `verilator` compile invocation, not just `echo`.
4. For each missing or stub file: either fix it with another `Write` call now, OR set `status: "partial"` in the upcoming `quality_report` and list the failure in `stub_details`. Do **not** silently drop the failure.

### Step 8 — Output

Output the `## fpga-tb-write:quality_report` JSON block (required last section). See Output Format below. The `status` field must reflect the result of Step 7 self-check — `status: "completed"` is only valid when every required file passed Step 7 verification.

## Output Artifacts

- `tb/tb_top.v` (TB top: clock, reset, driver, checker, timeout, PASS/FAIL)
- `tb/dut_inst.vh` (DUT instantiation with exact port mapping)
- `tb/scenario_matrix.md` (scenario coverage plan)
- `sim/run.sh` (optional, compile-only by default)
- `tb/handoff_packet.md`

**一次调用 = 一套 TB 产物**: All code blocks must be complete for `status: "completed"`. If any file is stub or shell-only, declare `partial` and report `stub_details`.

## Output Format (Critical — read before responding)

This skill runs in a fork subagent, so the subagent executes the work and reports back. The output format is **strongly constrained** to prevent the silent-data-loss failure mode where the model describes a completed TB without writing any files to disk.

### Mandatory primary style: `Write` / `Edit` tool calls

For every file listed in "Output Artifacts" that is being created or substantially rewritten, **you MUST call the `Write` tool** (or `Edit` for existing files). The tool call is what puts bytes on disk; without it, no file exists and the user sees "完成" while `tb/` is empty.

Order matters: make the tool calls before composing any prose or the trailing JSON block. The workspace scanner only counts files that exist on disk at the moment `quality_report` is emitted — describing a file in prose does not satisfy this requirement.

### When inline `## <path>` code blocks are acceptable (narrow case)

Inline code blocks are ONLY allowed in two narrow scenarios:

1. **Editing an existing file on disk** that you have already verified exists via `Glob`. Use the inline block to show the diff in chat; the actual write still goes through `Edit` (or `Write` to overwrite).
2. **Showing a short summary preview** (a few lines of a key TB module) for chat diff visibility, alongside the full `Write` tool call that landed the file. The file on disk is the source of truth; the code block is decoration.

Inline code blocks are **NOT** acceptable as a substitute for the `Write` tool on files that do not yet exist on disk. If you find yourself about to emit a `## tb/tb_top.v` code block without having called `Write` on `tb/tb_top.v`, stop and call `Write` first.

### Mandatory trailing block

End your reply with a `## fpga-tb-write:quality_report` fenced JSON block:

```json
{
  "status": "completed",
  "title": "short label",
  "reason": "",
  "files_written": [
    {"path": "tb/tb_top.v", "bytes": 4521, "lines": 142},
    {"path": "tb/dut_inst.vh", "bytes": 312, "lines": 18}
  ],
  "stub_details": [],
  "missing_inputs": [],
  "missing_files": []
}
```

Field rules:

- `status` must reflect Step 7 self-check. `completed` is only valid when every required file in "Output Artifacts" exists on disk with non-stub content.
- `files_written` is an explicit manifest of files that exist on disk after this call. This is the main agent's ground truth — even if your prose says "完成", if `files_written` is empty or incomplete, the user will be told the skill partially failed.
- `stub_details` lists files that exist but contain placeholder content (`// TODO`, `// ...`, single-line files, etc.). Each entry: `{"path": "...", "issue": "..."}`.
- `missing_files` lists required files from "Output Artifacts" that are NOT on disk. Each entry: `{"path": "...", "reason": "..."}`. This field is the primary signal for the main agent to surface a failure to the user.
- If `missing_files` is non-empty OR `stub_details` is non-empty, `status` MUST be `"partial"`, not `"completed"`.

### Status Values

| status        | When to use                                                                                | Result                                                                                  |
| ------------- | ------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------- |
| `completed`   | Every file in "Output Artifacts" exists on disk, `Write` tool calls confirmed via Glob, no stubs, no `// ...` placeholders, `files_written` non-empty | Main agent keeps files; user sees green completion                                      |
| `partial`     | At least one required file is missing from disk OR has stub content. `missing_files` or `stub_details` must be populated. | Main agent surfaces the partial failure to the user with the missing file list          |
| `needs_input` | Required upstream artifact is missing (e.g. no RTL file in `rtl/` to generate TB against)   | Main agent asks the user / upstream skill for the missing input                        |
| `error`       | Internal error, exception, or unrecoverable situation                                       | Main agent reports the error and asks for guidance                                      |

- [ ] No stub language anywhere: no `// ...`, `// TODO`, `// FIXME`, `// stub`
- [ ] All scenario matrix rows have concrete stimulus description
- [ ] Every file listed in `files_written` actually exists on disk (verified by `Glob` in Step 7)
- [ ] Every required file from "Output Artifacts" appears in `files_written` (otherwise it must be in `missing_files`)
- [ ] If `localparam MAX_COUNT` > 1_000_000: TB verifies behavioral correctness, not exact cycle count

If ANY item fails, output `status: "partial"` instead of `"completed"`.

**Always output quality_report as the last section** — even for `completed`.

## References

- **Anti-patterns**: See [references/tb_anti_patterns.md](references/tb_anti_patterns.md) for port direction errors, clock errors, defparam placement, stub patterns, wait style, and large localparam handling.
- **Self-check patterns**: See [references/tb_selfcheck_patterns.md](references/tb_selfcheck_patterns.md) for scenario types, scoreboard rules, clock period reference, timing calculations, and PASS/FAIL patterns.
- **Templates**: See `templates/tb_top.v`, `templates/dut_inst.vh`, `templates/scenario_matrix.md`, `templates/sim_run.sh`, `templates/handoff_packet.md`.
