# 行为规格与波形交接文档

## Read First

- `doc/spec/behavior_spec.md`
- `doc/spec/wave_plan.yaml`
- `doc/spec/wave_compare_rules.yaml`

## Recommended Next Skill

- Implement behavior: `fpga-rtl-build`
- Generate TB: `fpga-tb-write`
- Compile check: `fpga-compile-and-repair`
- Simulation / VCD: `fpga-sim-run`
