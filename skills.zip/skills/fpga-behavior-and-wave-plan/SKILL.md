---
name: 行为与波形规划
description: 该 Skill 编写可验证的 FPGA 行为规格、FSM/事务规则/不变量与波形检查计划，用于需要在 RTL/TB 前明确预期行为、观测信号、检查点和 first mismatch 比对规则时使用。
allowed-tools: [Read, Grep, Glob, Write, Edit]
user-invocable: true
argument-hint: "<optional: module_name>"
arguments: [module_name]
when_to_use: 当需要把关键行为前置成可验证规格，以提升 RTL/TB 正确性（例如协议握手、状态机切换、无撕裂切换、shadow 更新、故障锁存/清除等）时使用。
version: "0.1.0"
---

# Behavior Spec & Wave Plan

Use this skill to convert requirement language into rules that RTL, TB, and waveform analysis can all test.

## Boundaries

- Do not implement RTL or TB here.
- Do not require one universal format. Choose FSM tables, transaction rules, invariants, timing windows, or scenario tables based on the design.
- Every rule must have observable signals and a PASS/FAIL condition.
- Separate DUT errors, TB stimulus errors, expected-rule errors, and dump/sampling errors.

## Input Artifacts

Prefer these sources, in order:

1. `doc/intake/summary.md` and handoff packet
2. `doc/arch/interface_contract.yaml` and `rtl/top_skeleton.v`
3. `doc/reg/register_map.yaml` and `doc/reg/semantics_notes.md` when a control plane exists
4. Existing RTL/TB headers, failing sim logs, VCD/FST (when diagnosing an existing mismatch)

### Argument: module_name (optional)

If provided, treat it as the primary DUT focus for rule naming, wave signal scoping, and scenario naming. If not provided, derive it from the intake/architecture artifacts. Do not invent module names.

## Workflow

1. Read intake, architecture, register spec, existing RTL/TB, or failing sim notes.
2. Identify externally visible transactions, internal states worth observing, and configuration update points.
3. Separate confirmed facts from assumptions and open questions. If blocking facts are missing, record them explicitly in the spec artifacts instead of inventing them.
4. Write behavior spec with rule IDs. Include reset behavior, normal flow, boundary cases, error handling, recovery, and illegal conditions.
5. Define wave plan: signals, aliases, trigger events, windows, expected sequence, and minimum dump scope. If VCD is available for reference, use it to validate the plan. If no VCD, this plan serves as the basis for TB construction.
6. Define compare rules for first mismatch: sampling edge, tolerance, latency, don't-care windows, and classification.
7. Write a handoff packet naming the recommended next skill and the artifact paths it should read.
8. Output the trailing `## fpga-behavior-and-wave-plan:quality_report` JSON block. Do not emit any `ICCODER_ARTIFACT_MANIFEST_START/.../ICCODER_ARTIFACT_MANIFEST_END` JSON block—manifest output has been retired. The main agent composes the user-facing Chinese-language summary on its own.

Note: The scenario_matrix output by this skill covers **specification-level** test scenarios (behavior and expected signals). The scenario_matrix in `fpga-tb-write` covers **implementation-level** test cases (concrete stimulus sequences). They serve different purposes and are both necessary.

## Output Artifacts

- `doc/spec/behavior_spec.md`
- `doc/spec/wave_plan.yaml`
- `doc/spec/wave_compare_rules.yaml`
- `doc/spec/scenario_matrix.md`
- `doc/spec/handoff_packet.md`

## Output Format

This skill runs **inline** (in the main agent context). You have full access to Read, Grep, Glob, and Write tools — use them directly to create files.

## Completion Gate

The plan is complete when each critical behavior has a rule ID, trigger, observable signals, expected result, legal tolerance/window, and verification method. A downstream TB should be able to implement checks without reinterpreting the requirement.

## Bundled Resources

- `references/spec_patterns.md`: rule-writing patterns
- `templates/behavior_spec.md`, `templates/wave_plan.yaml`, `templates/wave_compare_rules.yaml`, `templates/scenario_matrix.md`, `templates/handoff_packet.md`
