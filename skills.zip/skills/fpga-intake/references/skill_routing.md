# Skill Routing

Use the narrowest skill that can make progress.

| User intent | Recommended skill |
| --- | --- |
| Raw requirement, unclear scope, missing acceptance | `fpga-intake` |
| Module partition, interface contract, top skeleton | `fpga-architecture` |
| Register map, AXI-Lite/APB control plane, side effects | `fpga-register-spec` |
| FSM rules, invariants, expected waveform checkpoints | `fpga-behavior-and-wave-plan` |
| Write or modify synthesizable Verilog | `fpga-rtl-build` |
| Compile/lint failure, minimal repair loop | `fpga-compile-and-repair` |
| Self-checking TB source generation | `fpga-tb-write` |
| Compile check only | `fpga-compile-and-repair` |
| Simulation run or VCD waveform generation | `fpga-sim-run` |
| Video pixel stream, sync, line buffer, frame switch | `fpga-video` |
| Fixed-point DSP, saturation, rounding, golden model | `fpga-dsp-fixedpoint` |
| valid/ready, packet stream, async FIFO, CDC | `fpga-stream-cdc` |
| RTL Wiki, project report, delivery checklist | `fpga-deliverables` |
| GJB/customer compliance style and document audit | `fpga-gjb-compliance` |
| Physical constraints, XDC/UCF/PCF, pin mapping | `fpga-xdc-gen` |

## Hardware Dependency Routing

When `fpga-intake` determines that a task needs board-level constraints:

| Scenario | Condition | Action |
| --- | --- | --- |
| Board configured + extraction needed | config.status = complete | `fpga-hw-manual-extraction` is called automatically |
| Board configured + extraction not needed | hw_dependency = none | Skip hardware flow, route to downstream skill |
| Board not configured + extraction needed | config.status = absent/partial | Prompt user to upload → `fpga-hw-manual-extraction` |

The hardware dependency assessment happens inside `fpga-intake` before routing decisions are made.
