---
name: 需求梳理
description: 该 Skill 将 FPGA/RTL/Verilog 需求澄清为单个可执行需求总结文档，用于用户提出 FPGA 任务但信息不足、目标含混、验收口径不明确或需要先判断下一步工程阶段时使用。
allowed-tools: [Read, Grep, Glob, AskUserQuestion, Write, Edit]
user-invocable: true
argument-hint: "<freeform>"
arguments: []
when_to_use: 当用户提出 FPGA/RTL/Verilog 相关需求但信息不完整，或不清楚从哪里开始、验收口径不明确时使用。
version: "0.3.0"
---

# FPGA Intake

Use this skill to turn a raw FPGA request into one stable engineering brief before architecture, RTL, TB, constraint, or debug work begins.

## Core Output Rule

- Produce exactly one user-facing intake document: `doc/intake/summary.md`.
- Fold missing information, evidence needs, assumptions, hardware dependency, and next-step handoff into sections inside `summary.md`.
- Do not create separate missing-info, evidence, or handoff markdown files. Never create legacy split files named `doc/intake/missing_info.md`, `doc/intake/evidence_needed.md`, or `doc/intake/handoff_packet.md`.
- Do not pad the output with user-irrelevant sections. If a section has no blocking content, state that briefly and explain why it does not affect the current goal.

## Boundaries

- Do not generate architecture, RTL, testbench, constraints, or repair patches in this skill.
- Do not invent board, pin, clock, reset, bus, timing, throughput, register, or acceptance facts.
- If enough information exists to proceed with a provisional draft, mark each assumption as provisional and list the owner who must confirm it.
- Prefer a short, prioritized missing-information section over a long interview.
- Ask only blocking questions. If a reasonable provisional path exists, record assumptions in `summary.md` and continue.

## Input Scan

Read the user request and any supplied requirement, code, log, VCD/FST, register table, board note, or previous project context. Extract:

- task type: new RTL, RTL modification, TB generation, compile failure, simulation mismatch, waveform diagnosis, timing/constraint issue, board bring-up, documentation, or compliance audit
- functional target: module behavior, protocols, data formats, rates, latency, throughput, and error handling
- interfaces: ports, buses, valid/ready rules, packet boundaries, registers, interrupts, memories, clocks, resets, CDC points
- verification target: scenarios, PASS/FAIL criteria, wave checkpoints, golden model, tool command, and required evidence
- delivery target: RTL, TB, scripts, reports, wiki, compliance package, constraints, or follow-up workflow

## Workflow

1. **Judge hardware dependency first.**

   A task usually needs board-level information when it involves constraint planning, pin mapping, XDC/UCF/PCF generation, concrete clock frequencies, IOSTANDARD, board peripherals, board bring-up, or hardware debug.

   A task usually does not need board-level information when it is pure RTL behavior, architecture without physical constraints, TB generation, simulation, compile repair, or documentation that does not depend on actual pins.

   Record the result in `summary.md` as `hw_dependency: none | partial | required`, with a one-sentence reason.

2. **Check board configuration only when hardware dependency is required or partial.**

   Read `doc/hw/config.json` if present and extract:

   - `status`: `"complete"` | `"partial"` | `"none"`
   - `language`, `chip.device`, `chip.series`, `vendor.id`, `vendor.name`, `toolchain`
   - uploaded sources such as XDC, pinmap, schematic, datasheet, or board notes

   If configuration is complete and constraint facts need extraction, route to `fpga-hw-manual-extraction`. If configuration is partial or absent, decide whether the gap blocks the current task:

   - Blocking: write the missing facts under `## Missing Information`, set manifest `status: "needs_input"`, and ask for the smallest useful upload or answer.
   - Non-blocking: write the gap under non-blocking confirmations inside `## Missing Information`, keep moving, and explain why current downstream work can proceed.

3. **Classify and route the task.**

   Choose the narrowest next skill:

   - direct synthesizable RTL: `fpga-rtl-build`
   - multi-module partition, protocol sequencing, or top-level contracts: `fpga-architecture`
   - register map or software-visible control plane: `fpga-register-spec`
   - waveform/spec planning: `fpga-behavior-and-wave-plan`
   - TB generation: `fpga-tb-write`
   - compile/lint repair: `fpga-compile-and-repair`
   - simulation/VCD: `fpga-sim-run`
   - physical constraints: `fpga-xdc-gen`

4. **Use the fast path for simple tasks.**

   走快速路径（fast path）—— 当请求是 FPGA 相关、单阶段、足够明确可以直接选择下一个 skill 而无需追问的情况：计数器、分频器、移位寄存器、同步器、简单 FSM、基础数据通路、独立的 TB 生成、或窄范围的编译/仿真检查。

   快速路径行为：

   - 不要追问澄清问题。
   - 只写 `doc/intake/summary.md`。
   - 把临时默认值放到 `## Assumptions and Defaults`。
   - 如果没有阻塞信息缺失，把"无阻塞信息缺失"写到 `## Missing Information`。
   - 在 `## Handoff and Next Step` 中记录建议的下一个 skill。

   当请求涉及多个互相作用的模块、协议时序、板级集成、CRC/checksum、CDC 策略、寄存器映射设计、约束规划、上电初始化、memory/buffering 架构或未定义顶层接口时，不要走快速路径。

5. **Write the consolidated summary.**

   `doc/intake/summary.md` 必须足够详细，让下游 skill 或工程师无需打开额外的 intake markdown 文件即可继续。除非确实不相关，否则按顺序包含以下章节（**文档总标题用中文，section 标题保持英文以维持下游 skill 的解析兼容**）：

   - `# <task> 需求梳理摘要`
   - `## Task Summary`
   - `## Confirmed Facts`
   - `## Hardware Dependency`
   - `## Assumptions and Defaults`
   - `## Missing Information`
   - `## Evidence Needed`
   - `## Acceptance Criteria`
   - `## Handoff and Next Step`

   For board-level constraint work, include a short note under `## Handoff and Next Step` that XDC generation normally needs a board-level top module (`top.v`) with board-facing ports such as LED, KEY, clock, reset, UART, or other physical signals. Keep it informational; do not make it a hard block unless the missing top-level contract actually blocks the next step.

## Output Artifacts

- `doc/intake/summary.md`：单个汇总的 intake 文档，包含任务摘要、已确认事实、硬件依赖、假设、缺失信息、所需证据、验收标准和下一步交接。

If writing files is not possible, output one inline artifact only:

- `doc/intake/summary.md`

## Completion Gate

The intake is complete when the single summary document satisfies one of these conditions:

- Downstream work has enough stable input to start.
- Blocking questions are explicit, minimal, and prioritized.

The summary must make all acceptance criteria observable through code review, compile output, simulation result, wave evidence, board test, or document review. Use `status: "needs_input"` only when continuing would require inventing critical facts.

## Skill Handoff

When intake is complete and a next skill is recommended:

- Put the recommended next skill name and reason in `## Handoff and Next Step` inside `doc/intake/summary.md`.
- Downstream skills should treat `doc/intake/summary.md` as the full intake brief.
- If requirements are clear and the next step is obvious, proceed to the next skill via the Skill tool.
- If clarification is needed from the user, ask the smallest blocking question directly.

## Output Format

This skill runs inline in the main agent context. Use Read, Grep, Glob, AskUserQuestion, Write, and Edit directly as needed.

After `doc/intake/summary.md` is written, output one short Chinese completion sentence, then the trailing `## fpga-intake:quality_report` JSON block. Do not output additional prose after the quality report. Do not emit any `ICCODER_ARTIFACT_MANIFEST_START/.../ICCODER_ARTIFACT_MANIFEST_END` JSON block—manifest output has been retired.

If outputting inline instead of writing files, use this exact shape and no additional intake files:

````markdown
## doc/intake/summary.md

```markdown
# <task> 需求梳理摘要
...
```
````

## Quality Report (Required)

When done, output one trailing `## fpga-intake:quality_report` JSON block describing outcome (`completed` when handoff is ready, `needs_input` when critical information is still missing). Do not emit any `ICCODER_ARTIFACT_MANIFEST_START/.../ICCODER_ARTIFACT_MANIFEST_END` JSON block—manifest output has been retired. The main agent composes the user-facing Chinese-language summary on its own.

**Quality report example:**

```json
{
  "status": "completed | needs_input | error",
  "title": "<task> 需求梳理完成",
  "reason": "",
  "intake_path": "doc/intake/summary.md",
  "missing_inputs": [],
  "next_skill": "<one of: fpga-architecture | fpga-register-spec | fpga-behavior-and-wave-plan | fpga-rtl-build | fpga-tb-write | fpga-compile-and-repair | fpga-sim-run | fpga-xdc-gen>"
}
```

## Bundled Resources

- `checklists/intake_questions.md`: question bank for different task types.
- `references/requirement_patterns.md`: patterns learned from provided FPGA cases and R&D requirement samples.
- `references/skill_routing.md`: routing guidance to other FPGA skills.
- `templates/intake_summary.md`: stable template for the single consolidated summary document.
