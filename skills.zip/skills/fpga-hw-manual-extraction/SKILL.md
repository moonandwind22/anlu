---
name: 硬件信息提取
description: Extracts FPGA board-level hardware facts from manuals, schematics, pin tables, and reference constraints. Use when constraint generation, board bring-up, or interface verification needs trustworthy pin mapping, clock, and IOSTANDARD evidence from source documents.
allowed-tools: [Read, Grep, Glob, Edit, Write]
user-invocable: true
argument-hint: "<optional: primary_hw_doc>"
arguments: [primary_hw_doc]
version: "0.4.1"
---

# FPGA Hardware Manual Extraction

Extract only the board-level hardware facts needed for the user's current FPGA task. This skill writes `doc/hw/extracted_facts.json` and, when needed, `doc/hw/extracted_facts.missing.md` directly into the workspace.

## Use this skill when

- The user wants to generate, update, verify, or prepare FPGA board constraints.
- The user needs pin, electrical, or clock facts recovered from hardware references.
- The user provides a board manual, schematic, pin table, or reference constraint file and wants constraint-relevant facts extracted.
- Downstream constraint work is blocked because the project lacks trustworthy pin, clock, or IOSTANDARD evidence.

Do not use this skill for pure RTL behavior design, protocol design, TB generation, or compile-only repair work that does not depend on board hardware facts.

## Execution mode

- This is an inline skill. Read project files and write artifacts directly in the workspace.
- Use `Write` and `Edit` when artifacts must be created or updated.
- Do not switch to fork-style text-only artifact output for normal execution.

## Boundaries

- Extract facts only. Do not generate final XDC, UCF, PCF, QSF, or SDC files.
- Scope extraction to the user's current hardware-facing task.
- Do not rewrite `doc/hw/config.json`.
- If required facts are incomplete, write `doc/hw/extracted_facts.missing.md` and keep `status: partial`.
- If task scope itself is ambiguous, use `status: needs_input` and ask only for the missing scope definition.

## Required fact groups

Every scoped signal must be evaluated against these three groups:

1. **`pin_map`**
   - Map each required board signal to a package pin.
   - If a package pin is not confirmed, mark it missing. Do not guess.
2. **`clock_facts`**
   - Confirm clock frequency and pin association for each required clock.
   - Derived values such as period from frequency are allowed only when the relationship is explicit.
3. **`electrical_facts`**
   - Prefer explicit `io_standard`.
   - If only electrical evidence such as bank or interface voltage exists, record that evidence instead of inventing an IOSTANDARD.

## Non-negotiable rules

- Do not write a pin number that is not confirmed in source material.
- Do not write a clock frequency that is not present in the source, even if it seems conventional.
- Do not write an IOSTANDARD that is not explicit in the source.
- Do not rename board signal names to guessed RTL port names.
- If a fact is unavailable, record the gap and keep `status: partial`.

## Scope selection

Infer the minimum hardware scope that still covers all required fact groups for the user's task.

Use this precedence:

1. Explicit user request in the current message.
2. Explicit hardware files or paths provided by the user.
3. Existing `doc/intake/summary.md` or `doc/intake/handoff_packet.md`.
4. Existing `doc/hw/extracted_facts.json` to preserve already confirmed facts for the same scope.
5. Other project context that clearly narrows the hardware target.

If the user's intent is ambiguous between unrelated hardware scopes, stop with `needs_input`.

## Inputs

Prefer sources in this order:

1. User-provided hardware references (via explicit path or Glob discovery):
   - board manual or datasheet (PDF)
   - schematic PDF or image
   - pin table in CSV, Excel, or Markdown
   - reference XDC, UCF, PCF, QSF, or SDC
2. Files under `doc/hw/` and its subdirectories — use Glob (e.g. `doc/hw/**/*.pdf`, `doc/hw/**/*.xdc`) rather than assuming a fixed subdirectory structure; VSCode extensions may organize uploaded files under `refs/`, directly under `hw/`, or elsewhere
3. `doc/intake/summary.md` and `doc/intake/handoff_packet.md` when they narrow hardware scope
4. Existing `doc/hw/extracted_facts.json` to preserve confirmed facts
5. `doc/hw/config.json` only as background context, never as the output target

If `primary_hw_doc` is provided, read it first and cross-check it against other available references.

See [references.md](references.md) for source-priority, field-normalization, and downstream-consumer notes.

## Workflow

1. Read the user's request and identify the concrete hardware-facing task.
2. Infer which signals are in scope and which fact groups apply to each.
3. If `doc/hw/extracted_facts.json` exists, read it first and preserve already confirmed facts unless stronger evidence contradicts them.
4. Rank hardware sources by confidence.
5. Navigate to the relevant sections, tables, or reference snippets.
6. Extract and normalize only the facts needed for the current task.
7. Preserve board-level signal names exactly as they appear in source material.
8. Record `source_ref` for every extracted fact.
9. Write `doc/hw/extracted_facts.json` directly into the workspace.
10. If any required fact group is missing for a scoped signal, write `doc/hw/extracted_facts.missing.md` and set `status: partial`.
11. If all required fact groups are present for every scoped signal, set `status: complete`.

## Output contract

The output file must include these sections at minimum. Additional fields are allowed.

### `pin_map`

```json
{
  "signal": "TXD",
  "package_pin": "D12",
  "source_ref": "doc/hw/refs/board_manual.pdf §3.4"
}
```

- `signal`: exact board-level name from source
- `package_pin`: FPGA package pin
- `source_ref`: exact evidence location

### `clock_facts`

```json
{
  "signal": "sys_clk",
  "frequency_mhz": 50.0,
  "period_ns": 20.0,
  "package_pin": "E3",
  "source_ref": "doc/hw/refs/board_manual.pdf §2.1"
}
```

- `signal`: clock source name
- `frequency_mhz` or `period_ns`: at least one must be present
- `package_pin`: include when available
- `source_ref`: exact evidence location

### `electrical_facts`

```json
{
  "signal": "TXD",
  "io_standard": "LVCMOS33",
  "bank_voltage": "3.3V",
  "interface_voltage": "3.3V",
  "evidence_kind": "explicit",
  "source_ref": "doc/hw/refs/board_manual.pdf §3.4"
}
```

- `signal`: must match the board-level name in `pin_map`
- `io_standard`: include only when explicit in source
- fallback fields may include `bank_voltage`, `interface_voltage`, or `interface_type`
- `evidence_kind`: `explicit` | `derived` | `fallback`
- `source_ref`: exact evidence location

## Status rules

- Set `status: complete` only when every scoped signal has all required fact groups satisfied.
- Set `status: partial` when any scoped signal is missing required pin, clock, or electrical evidence.
- Set `status: needs_input` when the task scope itself cannot be determined safely.
- Never substitute common practice or inference for unavailable facts.

## Output artifacts

- `doc/hw/extracted_facts.json`
- `doc/hw/extracted_facts.missing.md` when any required fact group is missing

These artifacts must be written to the workspace during normal execution.

## Handoff

- If extraction is complete, downstream constraint generation may consume `doc/hw/extracted_facts.json` together with RTL and any user-uploaded constraint templates.
- If any required fact group is missing, stop with `doc/hw/extracted_facts.missing.md` and ask only for the blocking references.

## About board-level `top` and XDC

XDC constraints map **board-level signals** (LED, KEY, clock, reset) to physical FPGA pins. This means there must be a board-level `top` module whose ports match the signal names in `extracted_facts.json`.

A common gap this skill does not detect: the current RTL already compiles and simulates cleanly, but its top-level ports are **internal bus signals** (e.g. `op_a`, `result`, `alu_op`) rather than board-level signals (`LED1`, `KEY1`, `clk`). In that case `extracted_facts.json` can be `complete` but the project still cannot generate a working XDC until a board-level `top` module is created.

When writing `extracted_facts.missing.md`, if the `scope` field in `extracted_facts.json` shows the current RTL top is an internal module (no board I/O ports), add a soft note:

```markdown
## 板级顶层缺口

当前 RTL 顶层（例如 `rv32i_alu`）是内部数据通路模块，端口为 `op_a`、`result` 等内部信号，
不含 LED/KEY/时钟等板级 I/O，无法直接映射到硬件手册中的管脚。

生成 XDC 之前，需要有一个板级顶层模块 `top.v`，例化内部模块并连接到板级接口。
这可以通过 `fpga-rtl-build` 直接生成板级顶层（当板级信号已知时），或通过 `fpga-architecture` 做顶层规划后生成。
```

This note should appear in `extracted_facts.missing.md` under a separate "板级顶层缺口" heading, not mixed into the `missing_facts` list. The note is informational — it does not change `status` or block extraction completion.
