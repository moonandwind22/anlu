---
name: 寄存器契约生成与审计
description: 该 Skill 生成并审计 FPGA 寄存器地图、字段语义、读写副作用与验证口径，用于设计包含 AXI-Lite/APB/自定义寄存器总线、Offset、RW/RC/W1C/WO、shadow、doorbell、计数器或软件可见状态时使用。
allowed-tools: [Read, Grep, Glob, AskUserQuestion]
user-invocable: true
argument-hint: "<optional: reg_table_file>"
arguments: [reg_table_file]
when_to_use: 当需求/设计中出现寄存器表、Offset、RW/RC/W1C/WO、AXI-Lite/APB/寄存器总线、软件可见状态与统计计数器时使用。本 Skill 为可选步骤，由 intake Agent 按需触发，无需每次都走此 Skill。
version: "0.1.0"
---

# FPGA Register Spec

Use this skill to create a register contract that software, RTL, TB, and documentation can all share.

## Boundaries

- Do not force AXI-Lite, APB, or a specific bus implementation if the request only needs semantic registers.
- Do not silently default reset values, access types, or field priorities. Mark missing facts.
- Every read/write side effect must include trigger, priority, clock domain, clear mechanism, and verification hook.
- Keep generated Markdown and structured YAML consistent.

### Argument: reg_table_file (optional)

If provided, treat it as the primary source of truth for offsets, access types, and reset values. Supported inputs:
- Markdown table / CSV exported from spec
- YAML/JSON regmap (preferred when available)
- Plain text notes (parse conservatively, mark missing facts)

If not provided, derive the initial map from `doc/intake/summary.md`, architecture handoff, and any existing RTL headers. Do not invent offsets/reset/access; mark them as missing when unknown.

## Workflow

1. Read requirement, architecture handoff, existing register tables, RTL, or docs.
2. Normalize all registers into a structured map: offset, width, reset, access, fields, side effects, owner clock domain.
3. Check address alignment, duplicate offsets, reserved holes, field overlap, reset consistency, and illegal access behavior.
4. Define special semantics: RC, W1C, W0C, WO, RO, shadow apply, doorbell, first-error latch, snapshot/freeze, counter clear, soft reset.
5. Write TB access plan: legal reads/writes, illegal access, byte strobes, side-effect checks, reset checks, CDC visibility.
6. When `doc/reg/register_map.yaml` exists, validate and render it using the bundled scripts:
   - Validate: `python3 scripts/regmap_validate.py doc/reg/register_map.yaml`
   - Render:   `python3 scripts/regmap_render_md.py doc/reg/register_map.yaml --out doc/reg/register_map.md`
   If validation fails, fix the YAML first, then re-run both commands.

If any of the following are missing and block correctness, ask only the minimal blocking questions:
- bus type expectations (AXI-Lite/APB/custom/semantic-only)
- base address and address width, alignment rule
- reset values, access types, illegal access policy
- side-effect trigger/priority and clock domain ownership

## Output Artifacts

- `doc/reg/register_map.yaml`: structured source of truth
- `doc/reg/register_map.md`: human-readable table
- `doc/reg/semantics_notes.md`: side effects, priorities, atomicity, CDC visibility
- `doc/reg/tb_access_plan.md`: verification sequences and coverage points
- `doc/reg/handoff_packet.md`: files and assumptions for RTL/TB

## Output Format

This skill runs **inline** (in the main agent context). You have full access to Read, Grep, Glob, and Write tools — use them directly to create files.

## Completion Gate

A register spec is complete when every field has all of the following:

- reset value
- access type
- bit range
- owner clock domain
- side-effect rule (trigger, priority, clear mechanism)
- illegal access behavior
- verification hook

If a field affects hardware across domains, the CDC visibility rule must be explicit.

## Bundled Resources

- `references/register_semantics.md`: semantics and priority rules
- `templates/register_map.yaml`, `templates/register_map.md`, `templates/semantics_notes.md`, `templates/tb_access_plan.md`, `templates/handoff_packet.md`
- `scripts/regmap_validate.py`: structural checks for the YAML template subset
- `scripts/regmap_render_md.py`: render Markdown from the structured map
