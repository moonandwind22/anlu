---
name: RTL生成
description: 该 Skill 生成或修改可综合 Verilog RTL。既可在已有架构/接口/行为契约约束下实现模块，也可直接处理简单明确的单模块 RTL 需求（如计数器、分频器、简单 FSM）。
allowed-tools: [Read, Grep, Glob, Write, Edit]
user-invocable: true
argument-hint: "<optional: file_or_module>"
arguments: [file_or_module]
when_to_use: 当需要按已确认的架构/接口/行为规格生成或修改可综合 RTL（Verilog）时使用。若命中 `rules/00-skill-routing.md` 中的“协议时序敏感模块判定标准”且协议边沿语义、初始化顺序、端口契约或关键状态转换仍未冻结，则不应直接进入本阶段。
model: iccoder-fpga
version: "0.1.0"
context: fork
---

# RTL Build (Verilog)

Use this skill to implement synthesizable RTL while preserving confirmed interfaces and downstream verification contracts. For simple standalone RTL requests, proceed directly with documented defaults.

## Boundaries

- Do not change confirmed ports, parameters, hierarchy, register semantics, or timing contract unless the change is explicitly requested or recorded as an architecture/register update.
- Default to synthesizable Verilog. Mark simulation-only code clearly and keep it out of RTL deliverables.
- Do not rewrite unrelated files. Make focused edits that preserve existing behavior.
- Prefer local coding style and module patterns already present in the repository.
- The skill runs in a fork subagent, but the subagent has access to the same `Write` / `Edit` tools as the main agent. Either deliver the artifacts as `## <path>` code blocks (the main agent parses them) or write the files directly — the main agent reconciles both via `_collectInternalCapabilityWorkspaceChanges` and `_mergeFinalizedFileChangeIntoList`, so the choice is yours. Use whichever feels natural for the artifact set.
- **Board-level `top` module is in scope**: if the request involves board-level signals (LED, KEY, clock, reset, etc.), this skill can generate `rtl/top.v` directly as the board-level wrapper — no need to go through `fpga-architecture` first. The `top` module instantiates internal modules and connects them to board-facing ports.

## Context Derivation (Critical — read before reading project files)

**Priority order — follow in order:**

1. If `doc/intake/summary.md` or `doc/intake/handoff_packet.md` exists → read it first for the full task brief.
2. If `doc/arch/interface_contract.yaml`, `doc/arch/connection_matrix.md`, or `doc/arch/handoff_packet.md` exists → read these **immediately after intake**. Architecture outputs define your port contracts, signal naming, clock domains, reset strategy, and submodule hierarchy. **Do not skip this step.**
3. If `doc/hw/config.json` exists → read it for chip/vendor constraints (clock frequencies, device family, I/O standards).
4. If invoked directly (no intake phase, no project files) → the request that triggered this skill is the single source of truth. **Implement it directly. Do NOT refuse.** A simple counter, divider, FSM, data path, or register file can always be implemented with sensible defaults:
   - Ports: at minimum `clk` and active-low `rst_n`
   - Module name: derive from the request (e.g. "counter" → `counter`)
   - Default width: 8 bits unless the request implies otherwise
   - For a clock divider request, derive a clear name such as `clk_div4`; use `clk`, active-low `rst_n`, and a divided clock output such as `clk_div4`
   - If ambiguous, make one reasonable choice and document it in `doc/spec/behavior_spec.md`
5. **Multi-module or protocol-heavy task — refuse only if top-level ports are undefined**: If the request involves multiple communicating sub-modules, undefined top-level ports, or a data-path plus control-path separation that the architecture phase has not yet resolved, do NOT generate full-system RTL. Output manifest `status: "needs_input"` with a clear list of what architecture must define first. However, if the architecture outputs from step 2 already define the port contracts and submodule boundaries, **generate each submodule independently** rather than refusing outright.
6. **Protocol-timing-sensitive module — refuse if contract is not frozen**: For a single module, if edge semantics, port contract, or phase ordering are NOT confirmed by existing intake/architecture/spec artifacts, do NOT guess. Output manifest `status: "needs_input"` and name the missing upstream artifact.

## Input Artifacts

Prefer these sources, in order:

1. `doc/hw/config.json` if present (chip, vendor, resources — **read this first**)
2. `doc/intake/summary.md` and `doc/intake/handoff_packet.md`
3. `doc/arch/interface_contract.yaml`, `doc/arch/connection_matrix.md`, and `rtl/top_skeleton.v`
4. `doc/reg/register_map.yaml` and `doc/reg/semantics_notes.md` when a control plane exists
5. `doc/spec/behavior_spec.md`, `doc/spec/wave_plan.yaml`, and `doc/spec/wave_compare_rules.yaml` when behavior/wave contracts exist
6. Existing RTL files and project build scripts when modifying an existing design

### Argument: file_or_module (optional)

If provided, it may be one of:

- a module name (focus implementation on that module and its immediate dependencies)
- a file path under the RTL tree (focus edits on that file and the minimal required support files)

If not provided, fall back to step 3 of Context Derivation above — derive the target from the request that triggered this skill. Do not invent module names or ports beyond what the request implies.

## Workflow

1. Read architecture, register spec, behavior spec, existing RTL, and relevant domain references.
2. Identify the smallest set of files to create or modify.
3. Preserve public interfaces. If an interface change is unavoidable, stop and route to `fpga-architecture` or `fpga-register-spec`.
4. Implement sequential logic with explicit reset behavior and combinational logic with complete assignments.
5. Align valid signals, data, sideband, and pipeline latency.
6. Separate confirmed facts from assumptions and open questions. Record assumptions, latency, resource-sensitive choices, verification hooks, and optional next stages inside `doc/spec/behavior_spec.md`; do not create separate note or handoff files for simple RTL generation.
7. Always create or update `doc/spec/behavior_spec.md` as a detailed behavior spec for the generated module so downstream TB work has an explicit contract.
8. Write RTL source files under `rtl/`.
9. Output the trailing `## fpga-rtl-build:quality_report` JSON block.
**一次调用 = 一个模块**：本 skill 一次调用只输出一个 RTL 模块（一个 `## rtl/<module>.v` 代码块）。不要试图一次生成多个模块。如果 architecture 定义了多个模块，请分别调用本 skill 多次，前一次完成并写盘后再调用下一次。
## Output Artifacts

- `rtl/**/*.v` or `rtl/**/*.sv` (可综合 RTL 源文件统一放在 workspace 根目录 `rtl/` 下)
- `doc/spec/behavior_spec.md` (detailed behavior contract, assumptions, timing, verification hooks, and optional next steps)
- `rtl/top.v` (board-level top wrapper, generated automatically when appropriate — see rule below)

### When to generate `rtl/top.v`

`top.v` is the board-level wrapper that instantiates the functional module and connects it to board-facing I/O. Whether to generate it is a **context-dependent judgment call** — use the module's interface semantics and the user's intent as signals:

| Signal | Judgment |
|--------|----------|
| Module ports are purely internal (data bus, protocol, memory interface) with no board-level meaning, AND `doc/hw/extracted_facts.json` or `doc/hw/config.json` contains board signal names (pin_map, clock_facts, electrical_facts) | **Generate** `top.v` — board signal names are known, no ambiguity; connect the module ports to the known board signals |
| Module ports are purely internal but no board signal names are available | **Consider** generating `top.v` with reasonable defaults (documented in `behavior_spec.md`); or defer until hardware info is prepared |
| Request mentions board-level signals (LED, KEY, button, switch, clock, reset) | **Consider** including `top.v` as the board entry point |
| Request is from an `fpga-architecture` output with a pre-defined top already in the artifact tree | **Do not** generate a new `top.v` — the architecture artifact is the source of truth |
| `rtl/top.v` already exists in the workspace | **Do not** overwrite — preserve the existing top |
| The generated module itself is the top-level design (its ports are board-facing by intent) | **Do not** generate an extra wrapper layer |
| User is focused on a single module for TB/debug purposes | **Do not** generate `top.v` — it adds noise for that intent |

The signals above are orientation cues, not hard gates. The strongest signal is **when board signal names are already known** — in that case, `top.v` has no ambiguity and should be generated. When board signal names are unknown, prefer deferring or using documented defaults rather than guessing.

**What `top.v` may contain:**

- Only combinational wiring — instantiate the functional module, connect signals
- Board-level ports: `clk`, `rst_n`, and whatever I/O the context implies (LED, button, uart pins, etc.)
- If a port connection cannot be inferred from context, use a plausible default (tie to 0, pull-up, clock divider, etc.) and **document the assumption** in `behavior_spec.md`
- Zero business logic — no FSM, no state, no control path beyond module instantiation

**What `top.v` must not contain:**

- Any functional behavior that belongs in the generated module
- Generated I/O that contradicts the module's port contract without explicit documentation

### Priority when architecture artifacts exist

When this skill is called **after** `fpga-architecture` or `fpga-intake`:

- Check whether `doc/arch/` already contains a `top.v`, `top_skeleton.v`, or any module with board-level ports. If yes, **do not generate a competing top wrapper** — the architecture artifact is the board-level entry point.
- If the architecture output references an existing `top` but that file does not yet exist on disk, generate it here as the deliverable that completes the architecture plan.
- When in doubt, prefer preserving the architecture's top-level structure over creating a new one.

When this skill is called **directly** (no upstream architecture phase):

- Apply the judgment signals above. A board-level `top.v` may be appropriate when the module's outputs need to reach physical pins and no existing top exists.
- Do not assume a top is needed just because the module has outputs — some modules are validated in isolation before board integration.

If writing files is not possible, output the artifacts inline in the chat using the exact filenames as section headers:
- rtl/**/*.v
- doc/spec/behavior_spec.md

## Completion Gate

RTL is ready for compile when:
- All module ports are stable and match interface contracts
- Reset-complete state is implemented for all state elements
- No obvious latches detected
- No unresolved implementation gaps remain
- All key behavior has a path to TB evidence
- No protocol-critical signal semantics are silently invented beyond the provided architecture/spec inputs

A manifest may use `status: "completed"` only when ALL of the following are true:
- The RTL contains complete module bodies, not only interfaces, empty `always` blocks, or placeholder wiring
- No `TODO`, `FIXME`, `TBD`, `...`, `stub`, "to be completed", "omitted", "shortened for brevity", "fill in later", or equivalent placeholder language appears in the RTL or behavior spec — this includes AXI/握手/状态机的中间阶段，只写 `// ...` 而不写实际逻辑判断
- FSM/state-machine logic is closed: no unfinished state branches, no branch that silently omits required assignments
- If the top module instantiates submodules, the required submodules are also emitted with real port mappings or the design stays single-module
- If a board-level `top.v` was emitted, verify that all its ports are physically connected (no floating inputs/outputs) and that the top-level module name is `top`
- `doc/spec/behavior_spec.md` is concrete enough for downstream TB generation and does not defer critical behavior to a later iteration
- Port names, parameter names, widths, and active-level semantics do not drift from the confirmed interface/spec inputs without an explicit recorded reason
- No obviously invalid target-language constructs appear in the RTL (for example unsupported operators/syntax for the declared Verilog dialect)
- No semantic substitution errors: the RTL uses constructs that directly express the intended semantics — do not substitute a different operator or construct that only coincidentally produces the same result in limited test cases (e.g., `&vec` for one-hot, `a - b <= 0` for comparison, `|` reduction for per-lane flag combination, implicit width arithmetic that overflows). See `references/verilog_antipatterns.md` for the full anti-pattern catalog.
- Protocol-critical sequencing is self-consistent: the implementation must not both drive and interpret the same edge/phase decision in contradictory ways within one control path

If any of the above is violated, do NOT claim `completed`. Use `status: "partial"` when a real but incomplete implementation exists, or `status: "needs_input"` when critical inputs are missing and continuing would require invention.

Treat the following as strong signals to stop and fall back to architecture/spec clarification instead of retrying RTL blindly:
- protocol-timing-sensitive modules that match the judging standard in `rules/00-skill-routing.md` and whose launch/sample edge, phase ordering, chip-select lifetime, framing rule, or init sequence is still inferred rather than confirmed
- generated RTL whose ports or parameter semantics drift from the confirmed contract
- generated RTL containing obvious language-invalid constructs or self-contradictory control sequencing

### AXI-Lite / Standard Bus Peripheral Checklist

For any module that implements AXI-Lite, APB, or similar standard bus interfaces, ALL of the following must be fully implemented:

**Write transaction (AW → W → B):**
- Write address state machine: `IDLE → ADDR_WAIT → DATA_WAIT → RESP` (or similar) with correct transition conditions (`awvalid/awready`, `wvalid/wready`, `bvalid/bready`)
- AW ready path: assert `awready` in correct state, clear on `awvalid & awready`
- W strobe handling: `wstrb` decoded per byte lane — each byte in `wdata` is written only if the corresponding `wstrb` bit is 1
- Write data register: capture `wdata` into internal register on `wvalid & wready`
- B response: assert `bvalid` with `bresp=0` (OKAY), wait for `bready`

**Read transaction (AR → R):**
- Read address state machine: `IDLE → ADDR_WAIT → DATA` with correct transition conditions
- AR ready path: assert `arready` in correct state, clear on `arvalid & arready`
- Read data drive: drive `rdata` and `rresp=0` (OKAY) on same cycle as `rvalid`
- R valid must stay stable until `rready` is asserted

**Register file:**
- Each address offset decoded with `case` or `if-else` chain — no partially-decoded registers
- Write-enable pulse for each register
- Read data mux selects correct source per address

**Do NOT abbreviate any of the above with `// ...` or omit the state transition logic.**

## Skill Handoff

When RTL implementation is complete:
- List optional next stages in the manifest `workflow_options`: TB generation, compile check, simulation, VCD, and XDC generation.
- Do not automatically continue to TB, compile, simulation, VCD, or XDC just because RTL finished.
- Continue only when the user explicitly requested that stage in the current turn, or when the user selected a workflow option generated by the previous manifest.
- For a request that only asks to write/design RTL, stop after RTL and the detailed behavior spec are produced.

## Output Format (Critical — read before responding)

This skill runs in a fork subagent, so the subagent executes the work and reports back. Pick whichever output style is most natural for the artifact set; the main agent handles the rest:

- **Inline `## <path>` code blocks** with a fenced language tag (verilog / markdown) — useful for keeping the manifest fields consistent and showing diffs in the chat UI.
- **Direct `Write` / `Edit` tool calls** — useful for large files, partial edits to existing files, or any case where you'd rather have the file system be the source of truth from the start.
- **A trailing `## fpga-rtl-build:quality_report` JSON block** at the end of your reply, with `status: "completed" | "partial" | "needs_input" | "error"`, so the main agent can decide whether to surface the result to the user. This is mandatory regardless of which output style you used above.

You can mix the two styles within a single call (e.g. write one file directly, emit a code block for another); `_mergeFinalizedFileChangeIntoList` de-duplicates by `workspaceRelativePath` and keeps the first `beforeText` / latest `afterText`.

### Hard requirements regardless of style

- Do NOT call `Bash` — compile, simulation, linting belong to `fpga-compile-and-repair` / `fpga-sim-run`. Bash is not in the tool list.
- Do NOT call `Agent` or `Task` — delegating to a deeper subagent would hide tool calls from the user and bypass the manifest pipeline. If the request needs to be decomposed, surface that as a `needs_input` instead.
- Do NOT emit stub logic, `// ...` placeholders, `TODO`, `FIXME`, `TBD`, or unfinished FSM branches. The completion gate below is the same regardless of output style.

### Code-block sections (when used)

When you choose the inline `## <path>` style, output only the following in this exact order, with nothing before or between the sections:

1. `## rtl/<module>.v` (or `rtl/<module>.sv`) — the RTL source, as a fenced verilog block
2. `## doc/spec/behavior_spec.md` — the behavior spec, as a fenced markdown block
3. *(optional)* `## rtl/top.v` — board-level top wrapper, as a fenced verilog block — output **only when** a top-level wrapper is appropriate for the current request (see "When to generate top.v" section). If generated, it goes here as block 3. If not, output exactly 2 blocks.

**Forbidden — do NOT add any of these around the code blocks:**
- Any text before the first `## ` heading (no "以下是产物", "开始生成", "已实现", etc.)
- Any text between file sections (no "行为规格如下", "RTL 源码:", etc.)
- Any text after the file sections (no "以上就是全部内容", "已整理产物", etc.)
- Duplicate introductions before each file section
- Bullet lists, tables, or prose summaries outside the code blocks
- Planning/progress wrap-up text such as "我将继续…", "接下来…", "还需要补充…", "下面给出…" or any other non-artifact closing prose
- `status: "completed"` together with stub-like output, placeholder logic, unresolved TODOs, or any statement that the implementation still needs a later pass
- `status: "needs_input"` together with seemingly final RTL file sections that would force the main agent to guess whether to write them

### RTL Source Files

```
## rtl/<module>.v

```verilog
// code here
```
```

### Detailed Behavior Spec

```
## doc/spec/behavior_spec.md

```markdown
// markdown content here
```
```

The behavior spec must be detailed enough for a different engineer or a downstream TestBench stage to verify the RTL without re-reading the prompt. Include these sections unless genuinely irrelevant:

1. `# <module> Behavior Specification`
2. `## Requirement Summary`
3. `## Public Interface` with a port table: name, direction, width, active level, description
4. `## Parameters and Defaults`
5. `## Clocking and Reset`
6. `## Functional Behavior` with cycle-by-cycle or state-by-state rules
7. `## Timing, Latency, and Throughput`
8. `## Assumptions and Chosen Defaults`
9. `## Edge Cases and Error Handling`
10. `## Synthesis Notes`
11. `## Verification Plan`
12. `## Acceptance Criteria`

For simple standalone RTL, the spec should still be complete: name every port, describe reset values, list exact counter/state transitions, document any default width or polarity choice, and give concrete TB scenarios. Do not write a short placeholder spec.

### Common Mistakes

- **Do not call `Bash`, `Agent`, or `Task`.** `Bash` belongs to compile/sim skills; `Agent` / `Task` would nest a hidden subagent and bypass the main agent's manifest pipeline. `Write` and `Edit` are available — use them when direct edits are cleaner than code blocks.
- **Do not emit `// ...` / `TODO` / `FIXME` / `TBD` / placeholder modules / unfinished FSM branches / promises to continue later** in the RTL or behavior spec — the completion gate is strict about stub content.
- **Always use a relative path from the workspace root** for `## <path>` headings (e.g. `rtl/counter.v`, not `/Users/.../counter.v`).
- **Do not write synthesizable RTL to `doc/rtl/*.v`**. RTL source files belong under workspace `rtl/`.
- **Always end with a `## fpga-rtl-build:quality_report` JSON block** describing the outcome. If you cannot produce the required files, output a single `needs_input` manifest instead of explanations, TODOs, placeholders, or "next step" prose.

### Quality Report (Required)

After all `## <path>` sections, output one trailing JSON block using `## fpga-rtl-build:quality_report` (see "Output Format" above). Do not output any `ICCODER_ARTIFACT_MANIFEST_START/.../ICCODER_ARTIFACT_MANIFEST_END` JSON block—manifest output has been retired. The main agent composes the user-facing summary on its own.

## Bundled Resources

- `references/synthesizable_verilog_rules.md`: coding rules and common pitfalls
- `references/rtl_integration_policy.md`: integration and edit-scope policy
- `references/verilog_antipatterns.md`: semantic substitution anti-patterns (comparisons, bit manip, width, mux logic)
- `templates/module.sv`, `templates/fsm.sv`, `templates/pipeline_stage.sv`, `templates/assertions.sv`
