# RTL 生成交接文档

## Read First

- `doc/rtl/notes.md`
- RTL sources under `rtl/`

## Optional Next Stages

- Generate TB source: optional, use when the user asks for TestBench or verification code.
- Compile check: optional, use when the user asks to check syntax or compile.
- Simulation run: optional, use when TB exists and the user asks to run simulation.
- VCD waveform: optional, enable only when the user explicitly asks for waveform/VCD evidence.
- XDC generation: optional, use when the user asks for board constraints and `doc/hw/config.json` plus pin references are available.

## Inputs To Pass

- `doc/rtl/notes.md`
- RTL file list and top module name (if known)
- Any build commands used and logs (if already run)

## Open Risks

| Risk | Impact | Mitigation |
| --- | --- | --- |

## Stop Conditions For Next Skill

- If an interface/contract mismatch is found, stop and route back to `fpga-architecture` / `fpga-register-spec` / `fpga-behavior-and-wave-plan` as appropriate.
