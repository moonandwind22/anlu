---
name: 编译检查
description: 该 Skill 对 RTL+TB 源码进行纯语法编译检查（iverilog -tnull），tool-first 定位语法错误并以最小补丁收敛修复。不运行仿真，不生成 VCD。
allowed-tools: [Bash, Read, Grep, Glob, Edit, Write]
user-invocable: true
argument-hint: "<optional: compile_entry>"
arguments: [compile_entry]
when_to_use: 当需要检查 RTL/TB 编译语法是否正确，或修复编译错误时使用。
version: "0.4.0"
---

# Compile & Check

Use this skill to verify RTL+TB compile cleanly with `iverilog -tnull`. No simulation, no VCD.

## Boundaries

- Run `iverilog -tnull` only — Do NOT run `vvp` or generate any `.vvp` files.
- Diagnostics must come from real tool output.
- Do not perform broad rewrites to fix syntax errors; apply the smallest patch.
- Do not ignore warnings that change behavior, synthesis, width, signedness, latch inference, CDC, or reset semantics.
- Stop after 3 failed repair attempts and write a repair plan instead of continuing to churn.
- Do not suggest installing toolchains via brew/apt/yum. Use `iverilog` from PATH.

## Context Derivation (Critical — read before reading project files)

**Priority order — follow in order, stop at the first hit:**

1. If `doc/intake/handoff_packet.md` exists → read it first for module names.
2. If `doc/rtl/notes.md` exists (from `fpga-rtl-build`) → read it for additional context.
3. If invoked directly (no handoff packet) → find sources by scanning the workspace:
   - RTL: look in `rtl/*.v`, `rtl/*.sv` first; only read `doc/rtl/*.v` or `doc/rtl/*.sv` as legacy input if present
   - TB: look in `tb/*.v`, `tb/*.sv`
   - Do NOT refuse if handoff_packet.md is missing.

## Input Artifacts

Prefer these sources, in order:

1. `doc/hw/config.json` if present (chip, vendor)
2. `doc/intake/summary.md` and `doc/intake/handoff_packet.md`
3. `doc/rtl/notes.md` (if the request follows rtl-build)
4. Architecture/register/behavior contracts if relevant:
   - `doc/arch/interface_contract.yaml`
   - `doc/reg/register_map.yaml`
   - `doc/spec/behavior_spec.md`
5. Existing RTL sources and TB sources found in the workspace

### Argument: compile_entry (optional)

If provided, specifies the compile entry. May be:
- a top-level file (`.v` / `.sv`)
- `tb_top=<module>` — TB top module (default: `tb_top`)
- `rtl_top=<module>` — RTL top module
- Or a combination: `tb_top=<tb> rtl_top=<rtl>`

If not provided, scan the workspace for RTL and TB files, then derive from file names. Do not refuse.

## Tool Path

**查找顺序（按优先级）：**

1. **PATH**：先尝试 `iverilog --version` 验证 iverilog 是否在 PATH 中。
2. **ICCODER_TOOLS_ROOT**：如果 PATH 中找不到，检查 `$ICCODER_TOOLS_ROOT/bin/iverilog`。
3. **直接路径**：如果以上都失败，报告阻塞，停止编译检查。

**vvp 路径解析**（用于后续仿真）：
```bash
# 方法1：使用 dirname
vvp_path="$(dirname $(which iverilog))/vvp"

# 方法2：使用 ICCODER_TOOLS_ROOT
if [[ -z "$iverilog_path" && -n "$ICCODER_TOOLS_ROOT" ]]; then
  vvp_path="$ICCODER_TOOLS_ROOT/bin/vvp"
fi
```

**阻塞条件**：如果 iverilog 工具完全不可用，立即停止并报告阻塞原因。

## Workflow

### Step 1 — 准备编译环境

1. Identify all RTL source files: scan `rtl/` for `.v` and `.sv` files. If legacy `doc/rtl/*.v` or `doc/rtl/*.sv` files exist, include them for compatibility but do not create new RTL there.
2. Identify all TB source files: scan `tb/` for `.v` and `.sv` files.
3. Determine the TB top module name. If not given, use `tb_top` or derive from file names.
4. Determine include paths (`-I rtl -I tb`, with `-I doc/rtl` only for legacy compatibility when legacy source files exist).

### Step 2 — 纯语法编译

5. Run `iverilog -tnull` to check syntax without generating output:

```sh
iverilog -g2012 -Wall \
  -I rtl -I tb \
  -s <tb_top_module> \
  rtl/*.v rtl/*.sv tb/*.v tb/*.sv \
  > sim/compile.log 2>&1
```

`-tnull` skips simulation target generation; omitting `-o` avoids `.vvp` output.

6. Save raw log under `sim/compile.log` and write the summary report under `doc/compile/check_report.md`.

### Step 3 — 诊断与修复

**If compile succeeds** (exit code 0):
- Compilation is clean. Write `doc/compile/check_report.md` with PASS status.
- Optional next stage: `fpga-sim-run` if the user wants to run the self-checking TB; otherwise stop after the compile report.

**If compile fails** (non-zero exit code):
7. Parse `sim/compile.log` for error messages (file, line, reason).
8. Apply the smallest patch to fix the errors — one logical fix batch.
9. Re-run Step 2.
10. After 3 failed attempts: write `doc/compile/repair_report.md` with diagnostics, patch list, and convergence status. Stop.
11. If an error points to missing spec or interface ambiguity, stop and route to `fpga-rtl-build` with diagnostics.

### Step 4 — 产出报告

12. Write `doc/compile/check_report.md` with:
    - compile status (PASS/FAIL with exit code)
    - diagnostics summary if failed
    - patch list if repaired
    - recommended next skill
13. Output the fixed artifact manifest block described in `rules/60-fpga-artifact-manifest.md`.

## Output Artifacts

- `sim/compile.log` (raw iverilog output)
- `doc/compile/check_report.md` (PASS/FAIL, diagnostics, next skill)
- `doc/compile/repair_report.md` (on convergence failure — diagnostics, patches, root cause)
- patched RTL/TB files when repair is needed

## Quality Report

When done, output one trailing `## fpga-compile-and-repair:quality_report` JSON block. Include `compile_log_path`, `check_report_path`, any `repair_report_path`, and any patched RTL/TB paths. Use `status: "completed"` for clean compile, `partial` for repaired-but-needs-review, `failed` for convergence failure, `error` for unexpected tool failure.

Do not emit any `ICCODER_ARTIFACT_MANIFEST_START/.../ICCODER_ARTIFACT_MANIFEST_END` JSON block—manifest output has been retired. The main agent composes the user-facing Chinese-language summary on its own.

## Completion Gate

Done when:
- Compile exit code 0 → `doc/compile/check_report.md` written with PASS, OR
- Convergence failure → `doc/compile/repair_report.md` written with diagnostics and next skill

## Skill Handoff

- Compile passes → optionally offer `fpga-sim-run` if TB exists and the user wants simulation evidence
- Compile fails with RTL logic error → recommend `fpga-rtl-build` with diagnostics
- Compile fails with TB error → recommend `fpga-tb-write` with diagnostics

## Bundled Resources

- `scripts/compile_iverilog.sh` (standalone compile, no sim)
- `scripts/parse_compile_log.py` (structured diagnostics)
- `references/minimal_patch_policy.md`
- `templates/check_report.md`
