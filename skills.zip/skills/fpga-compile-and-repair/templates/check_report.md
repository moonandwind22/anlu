# 编译检查报告

## Compile Result

| Item | Value |
| --- | --- |
| Status | PASS / COMPILE_FAIL |
| Exit Code | 0 / non-zero |
| Log | `sim/compile.log` |
| Command | (from `sim/sim_result.json.command`) |

## Diagnostics (if failed)

| Severity | File | Line | Message | Root Cause |
| --- | --- | --- | --- | --- |

## Patches Applied (if any)

| File | Change | Reason |
| --- | --- | --- |
| | | |

## Remaining Issues

-

## Recommended Next Skill

- If compile failed after 3 attempts: `fpga-tb-write` (revise TB) or `fpga-rtl-build` (fix RTL)
- If compile passed and user wants runtime evidence: `fpga-sim-run`
- If compile passed and user did not request simulation: done
