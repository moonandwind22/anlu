# 编译修复报告

## Command

```sh
# exact command here
```

## Result

- Status:
- Tool:
- Log:

## Diagnostics

| Severity | File | Line | Message | Root cause |
| --- | --- | --- | --- | --- |

## Patches Applied

| File | Change | Reason |
| --- | --- | --- |

## Remaining Issues

- 

## Recommended Next Skill

-
