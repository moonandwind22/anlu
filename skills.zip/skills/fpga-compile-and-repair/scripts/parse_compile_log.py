#!/usr/bin/env python3
import argparse
import json
import re
import sys
from pathlib import Path


PATTERNS = [
    re.compile(r"^(?P<file>[^:\s][^:]*):(?P<line>\d+):(?:(?P<col>\d+):)?\s*(?P<severity>error|warning|syntax error|fatal)[:\s]+(?P<message>.*)$", re.I),
    re.compile(r"^%(?P<severity>Error|Warning|Fatal)[^:]*:\s*(?P<file>[^:]+):(?P<line>\d+):(?:(?P<col>\d+):)?\s*(?P<message>.*)$", re.I),
    re.compile(r"^(?P<file>[^:\s][^:]*):(?P<line>\d+):\s*(?P<message>.*syntax error.*)$", re.I),
]


def parse(text):
    diagnostics = []
    for raw in text.splitlines():
        line = raw.rstrip()
        for pattern in PATTERNS:
            match = pattern.match(line)
            if match:
                item = match.groupdict()
                item["raw"] = line
                item["line"] = int(item["line"]) if item.get("line") else None
                item["col"] = int(item["col"]) if item.get("col") else None
                sev = item.get("severity") or "error"
                item["severity"] = "error" if "syntax" in sev.lower() else sev.lower()
                diagnostics.append(item)
                break
    return diagnostics


def main():
    parser = argparse.ArgumentParser(description="Parse common Verilog compile logs into JSON diagnostics.")
    parser.add_argument("log", nargs="?", default="-")
    parser.add_argument("--out", default="-")
    args = parser.parse_args()
    text = sys.stdin.read() if args.log == "-" else Path(args.log).read_text(encoding="utf-8-sig", errors="replace")
    text = text.lstrip("\ufeff")
    data = {"diagnostic_count": 0, "diagnostics": parse(text)}
    data["diagnostic_count"] = len(data["diagnostics"])
    output = json.dumps(data, ensure_ascii=False, indent=2)
    if args.out == "-":
        print(output)
    else:
        Path(args.out).write_text(output + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
