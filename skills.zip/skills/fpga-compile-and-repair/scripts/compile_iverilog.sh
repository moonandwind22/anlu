#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "usage: compile_iverilog.sh <file-or-filelist> [iverilog args...]" >&2
  exit 2
fi

# Find iverilog: try PATH first, then ICCODER_TOOLS_ROOT fallback
find_iverilog() {
  # Try PATH first
  if iverilog_path="$(which iverilog 2>/dev/null)" && [[ -x "$iverilog_path" ]]; then
    echo "$iverilog_path"
    return 0
  fi

  # Fallback to ICCODER_TOOLS_ROOT
  if [[ -n "${ICCODER_TOOLS_ROOT:-}" ]]; then
    candidate="$ICCODER_TOOLS_ROOT/bin/iverilog"
    if [[ -x "$candidate" ]]; then
      echo "$candidate"
      return 0
    fi
  fi

  return 1
}

iverilog_path="$(find_iverilog)" || {
  echo "iverilog not found. Tried: PATH and \$ICCODER_TOOLS_ROOT/bin/iverilog" >&2
  echo "Ensure the IC Coder VSCode extension is properly installed." >&2
  exit 127
}

if [[ ! -x "$iverilog_path" ]]; then
  echo "iverilog is not executable: $iverilog_path" >&2
  exit 127
fi

entry="$1"
shift

# -tnull: use null target (no simulation output, no .vvp file)
# -o is intentionally omitted to avoid generating .vvp for syntax-only checks
iverilog_args=(-g2012 -tnull)

if [[ "$entry" == *.f || "$entry" == *.flist ]]; then
  iverilog_args+=(-f "$entry")
else
  iverilog_args+=("$entry")
fi

iverilog_args+=("$@")

exec "$iverilog_path" "${iverilog_args[@]}"
