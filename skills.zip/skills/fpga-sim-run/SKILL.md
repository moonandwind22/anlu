---
name: 仿真运行
description: 仅在用户明确要求运行仿真或生成 VCD 时使用。该 Skill 运行已有 RTL+TB 的仿真，按需启用 VCD，并产出 sim 日志、结果 JSON 和波形文件；不生成 RTL，不生成 TB。
allowed-tools: [Bash, Read, Grep, Glob, Write, Edit]
user-invocable: true
argument-hint: "<optional: run_sim | generate_vcd>"
arguments: [mode]
when_to_use: 当用户明确要求跑仿真、执行 vvp、验证 TestBench 运行结果、生成 VCD/波形时使用。
version: "0.1.0"
---

# Simulation Run

Use this skill only after the user explicitly asks to run simulation or generate VCD/waveform evidence. This stage is optional and cost-sensitive. Do not run it just because RTL or TB generation completed.

## Boundaries

- Run simulation only for existing RTL and TB sources.
- Do not generate RTL source. Route missing RTL to `fpga-rtl-build`.
- Do not generate TB source. Route missing TB to `fpga-tb-write`.
- VCD is off by default. Enable VCD only when the user explicitly asks for VCD/waveform, or when mode is `generate_vcd`.
- Use the plugin-provided `iverilog`/`vvp` from PATH. Do not suggest installing toolchains through system package managers.
- Keep simulation outputs under `sim/` and reports under `doc/compile/`.

## Context Derivation

1. Read `doc/intake/handoff_packet.md`, `doc/compile/check_report.md`, and `tb/handoff_packet.md` if present.
2. Scan `rtl/` for `.v` / `.sv` sources.
3. Scan `tb/` for `.v` / `.sv` sources.
4. If `sim/run.sh` exists, prefer it as the simulation entry because it already encodes local include paths and top module defaults.
5. If `sim/run.sh` is missing but RTL and TB exist, create a minimal `sim/run.sh` based on the TB run template: compile by default, run only when `RUN_SIM=1`, and generate VCD only with `ENABLE_VCD=1`.

## Mode Selection

- `run_sim`: run compile + simulation with `RUN_SIM=1 ENABLE_VCD=0`.
- `generate_vcd`: run compile + simulation with `RUN_SIM=1 ENABLE_VCD=1`.
- If the user says "VCD", "波形", or "看波形", treat it as `generate_vcd`.
- Otherwise, default to `run_sim`.

## Workflow

1. **查找 iverilog/vvp**：
   - 第一步：尝试 `iverilog --version` 验证 iverilog 是否在 PATH 中。
   - 第二步：如果 PATH 中找不到，检查 `$ICCODER_TOOLS_ROOT/bin/iverilog`。
   - 第三步：vvp 通常位于同一目录，可通过 `dirname $(which iverilog)` 或 `$ICCODER_TOOLS_ROOT/bin/vvp` 获取。
   - 如果完全找不到 iverilog/vvp：**立即报告阻塞原因，停止仿真任务**。
2. **路径格式规则**（重要）：
   - **所有路径必须使用相对路径**，不要硬编码绝对路径（如 `/d/...`、`/c/...`、`D:\...`）。
   - 使用 `$PWD` 动态获取当前目录：例如 `vcd_file="$PWD/sim/wave.vcd"`。
   - 如果需要拼接路径，使用 `$(pwd)` 或 `$PWD` 而不是手动构造。
3. Verify at least one RTL source exists under `rtl/`.
4. Verify at least one TB source exists under `tb/`.
5. Ensure `sim/run.sh` exists and is executable when the platform supports chmod.
6. Run:
   - without VCD: `RUN_SIM=1 ENABLE_VCD=0 bash sim/run.sh`
   - with VCD: `RUN_SIM=1 ENABLE_VCD=1 bash sim/run.sh`
7. Capture logs in `sim/compile.log`, `sim/sim.log`, and `sim/sim_result.json`.
8. Write `doc/compile/run_report.md` summarizing command, PASS/FAIL status, logs, and VCD path when generated.
9. If compile fails, do not repair here; route to `fpga-compile-and-repair`.
10. If simulation fails because TB expectations are wrong, route to `fpga-tb-write`; if DUT behavior is wrong, route to `fpga-rtl-build`.
11. Output one artifact manifest block.

## Output Artifacts

- `sim/compile.log`
- `sim/sim.log`
- `sim/sim_result.json`
- `sim/wave.vcd` when VCD is requested and generated
- `doc/compile/run_report.md`

## Quality Report (Required)

When done, output one trailing `## fpga-sim-run:quality_report` JSON block describing outcome, simulation command exit status, log paths, and any VCD file produced. Use `status: "completed"` for clean sim, `partial` for warnings worth reviewing, `failed` for failing assertions / non-zero exit.

Do not emit any `ICCODER_ARTIFACT_MANIFEST_START/.../ICCODER_ARTIFACT_MANIFEST_END` JSON block—manifest output has been retired. If the user only asked for sim (not VCD), the main agent's user-facing summary may offer "生成 VCD" as a one-line next step.

## Completion Gate

Done when:

- Simulation command exits 0 and report is written, OR
- The command fails and the report captures the failing stage, log path, and next repair stage.

## Bundled Resources

- `references/sim_manifest_example.json`: full artifact manifest example
