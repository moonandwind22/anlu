---
name: 架构设计
description: 该 Skill 设计 FPGA 模块拆分、接口契约、时钟复位与 CDC 策略，并生成 RTL 顶层骨架。适用于多模块系统、协议/初始化时序、板级接口或顶层边界尚未稳定的复杂任务，在进入可实现架构与 top skeleton 阶段前使用。
allowed-tools: [Read, Grep, Glob, Write, Edit, AskUserQuestion]
user-invocable: true
argument-hint: "<optional: module_name>"
arguments: [module_name]
when_to_use: 当任务在进入 RTL 之前需要先稳定系统结构时使用，例如：多模块拆分、顶层端口/子模块边界未定、协议初始化或时序编排、跨时钟域/复位策略、板级接口/黑盒 IP 封装、缓存/FIFO/存储架构选择，或 intake 已判定下一步依赖架构决策而非直接编码。若命中 `rules/00-skill-routing.md` 中的“协议时序敏感模块判定标准”，且关键契约尚未冻结，也应先进入本阶段。
version: "0.1.0"
---

# FPGA Architecture

Use this capability to produce a stable implementation contract for later RTL, TB, compile, simulation, XDC, and wave-analysis work.

All user-visible wording must use the public product name "IC Coder". Do not mention internal capability names, model names, provider names, prompt names, or source paths in user-visible prose, handoff files, or manifest fields.

## Boundaries

- Generate architecture artifacts and RTL skeletons only. Do not implement business logic.
- This stage exists to freeze engineering boundaries before RTL. Use it when direct coding would otherwise force the model to guess module partitioning, top-level interfaces, initialization ordering, CDC ownership, board wrappers, or memory strategy.
- Protocol-timing-sensitive controllers are not treated as "simple RTL" by default. Follow the judging standard in `rules/00-skill-routing.md` under “协议时序敏感模块判定标准”; if the required contract is not already frozen, architecture must lock those rules first.
- Do NOT create implemented submodule RTL such as `rgb2ycbcr.v`, `sobel.v`, `reset_sync.v`, FIFO RTL, PLL wrappers, HDMI encoder logic, or full data-path logic.
- Do NOT generate `rtl/top.v`. 不要生成 `rtl/top.v`。The only architecture RTL file is `rtl/top_skeleton.sv`.
- Do not change user-confirmed ports, registers, clock domains, or protocol semantics without recording a required upstream decision.
- Treat vendor hard IP, transceivers, memory controllers, CPU cores, PHYs, and board-specific primitives as black boxes unless source is provided.
- Keep CDC decisions explicit: control sync, data FIFO, reset sync, or same-domain proof.
- If hardware details are missing, make conservative architecture assumptions and record them in `doc/arch/risks.md`; ask only when a choice blocks even a safe architecture draft.

## Context Derivation (Critical)

Follow this order exactly:

1. If the user gives a direct architecture request and does not mention existing project files, uploaded hardware files, or a saved `doc/hw/config.json`, do not call Read, Grep, or Glob. Produce the standard seven-file architecture package directly from the user request and the defaults below.
2. If the user explicitly says hardware information, existing RTL, specs, or uploaded files are present, use Glob before Read and read only the minimum required user-provided files.
3. Never read the output paths before generating them. In a new workspace these files do not exist yet:
   - `doc/arch/interface_contract.yaml`
   - `doc/arch/clock_reset_cdc.md`
   - `doc/arch/module_partition.md`
   - `doc/arch/connection_matrix.md`
   - `rtl/top_skeleton.sv`
   - `doc/arch/risks.md`
   - `doc/arch/handoff_packet.md`
4. Do not read bundled templates with relative paths such as `templates/interface_contract.yaml`. If a bundled reference is absolutely necessary, use `${CLAUDE_SKILL_DIR}/templates/...`; otherwise rely on the output format and example in this file.

## Input Artifacts

Prefer these sources, in order:

1. `doc/intake/summary.md` and handoff packet
2. `doc/hw/config.json` if present (chip device, vendor, resources, IO standards — **read this before proceeding**)
3. Product requirement, register table, protocol note, datasheet, or existing RTL headers
4. Existing top/module files if this is an update
5. Domain references from bundled video, DSP, or CDC architecture patterns when relevant

## Default Assumptions

Use these defaults only when the user and `doc/hw/config.json` do not provide stronger facts:

- For camera-to-display exercises, 默认采用 640x480@60Hz as the first-pass target to keep timing and memory feasible on small FPGA boards.
- For RGB565 camera input, assume an 8-bit DVP-style camera stream with two-byte RGB565 assembly unless the source says MIPI, AXI, or parallel 16-bit.
- For HDMI output, treat TMDS/serializer/vendor output primitives as black boxes and define their wrapper interface only.
- Prefer 纯流式 + 行缓存 architecture for Sobel and similar 3x3 image filters. Do not introduce DDR/frame-buffering unless explicitly required by resolution, clock mismatch, overlay, or random access needs.
- If camera pixel clock and display pixel clock differ, bridge pixel payload plus frame/line sideband through an async FIFO. Synchronize frame-level control separately.
- Keep Sobel threshold, bypass, test-pattern, and resolution controls as optional control-plane signals unless the user explicitly asks for a register map.

## Workflow

1. Identify top module, external interfaces, internal submodules, black boxes, and ownership boundaries.
2. Capture architecture assumptions separately from confirmed requirements.
3. Create `doc/arch/interface_contract.yaml`: every external port and submodule port must include direction, width, clock domain, reset domain, protocol, and semantic notes.
4. Create `doc/arch/clock_reset_cdc.md`: list all clock domains, reset synchronizers, data CDC, control CDC, and verification evidence.
5. Create `doc/arch/module_partition.md`: module table, owner/responsibility, state/FIFO/RAM ownership, and black boxes.
6. Create `doc/arch/connection_matrix.md`: producer, signal group, consumer, protocol, clock domain, latency/backpressure notes.
7. Create `rtl/top_skeleton.sv`: compile-oriented top-level skeleton with parameters, ports, local wires, black-box submodule instances, and no business logic.
8. Create `doc/arch/risks.md`: assumptions, unresolved hardware facts, timing/resource risks, and downstream evidence requirements.
9. Create `doc/arch/handoff_packet.md`: concise handoff pointing to the generated artifacts and public next steps.

## Output Artifacts

- `doc/arch/interface_contract.yaml`
- `doc/arch/clock_reset_cdc.md`
- `doc/arch/module_partition.md`
- `doc/arch/connection_matrix.md`
- `rtl/top_skeleton.sv`
- `doc/arch/risks.md`
- `doc/arch/handoff_packet.md`

If writing files is not possible, output the key artifacts inline in the chat using the exact filenames as section headers:
- doc/arch/interface_contract.yaml
- doc/arch/clock_reset_cdc.md
- doc/arch/module_partition.md
- doc/arch/connection_matrix.md
- rtl/top_skeleton.sv
- doc/arch/risks.md
- doc/arch/handoff_packet.md

Do not use alternate filenames for architecture output.

Forbidden output paths for this capability:

- `doc/arch/architecture.md`
- `doc/arch/cdc_strategy.md`
- `doc/arch/interface_contract.md`
- `rtl/top.v`
- `rtl/reset_sync.v`

If you are about to write any forbidden path, rewrite the output into the standard seven-file architecture package instead.

## Completion Gate

Architecture is complete when every external port and submodule interface has an owner, clock/reset domain, protocol rule, and downstream verification hook. Any unresolved decision must be visible as an open question, not hidden in RTL comments.

Use architecture before RTL whenever direct implementation would otherwise require guessing any of the following:
- top-level external ports or board-facing wrappers
- submodule partitioning or ownership boundaries
- protocol bring-up / initialization sequencing
- CDC method selection or reset-tree ownership
- memory buffering strategy such as line buffer vs frame buffer vs async FIFO
- black-box IP wrapper boundaries or vendor primitive encapsulation
- protocol edge semantics such as launch/sample edge, chip-select lifetime, phase ordering, or command/response boundary rules in a timing-sensitive controller

## Bundled Resources

- `references/clock_reset_cdc_patterns.md`: CDC and reset decision patterns
- `references/architecture_patterns.md`: architecture patterns from supplied FPGA requirement samples
- `templates/interface_contract.yaml`
- `templates/clock_reset_cdc.md`
- `templates/module_partition.md`
- `templates/connection_matrix.md`
- `templates/top_skeleton.sv`
- `templates/risks.md`
- `templates/handoff_packet.md`

## Output Format (Critical)

This skill runs **inline** (in the main agent context). You have full access to Read, Grep, Glob, and Write tools — use them directly to create files.

When this skill runs inline, write all generated files directly using the Write tool. Do not output file content as inline markdown text blocks.

After all files are written, output one short Chinese completion sentence followed by a trailing `## fpga-architecture:quality_report` JSON block. Do not output additional prose after the block. Do not emit any `ICCODER_ARTIFACT_MANIFEST_START/.../ICCODER_ARTIFACT_MANIFEST_END` JSON block—manifest output has been retired.

**Output shape:** Each artifact uses a `## <workspace-relative-path>` heading followed by a fenced code block. The seven standard artifacts are: `doc/arch/interface_contract.yaml`, `doc/arch/clock_reset_cdc.md`, `doc/arch/module_partition.md`, `doc/arch/connection_matrix.md`, `rtl/top_skeleton.sv`, `doc/arch/risks.md`, `doc/arch/handoff_packet.md`.

**Common mistakes:**
- Do not output file content without a `## <workspace-relative-path>` heading.
- Do not use absolute paths.
- Do not write implementation RTL or helper RTL in the architecture stage.
- Do not continue to RTL, TB, compile, simulation, VCD, or XDC unless the user explicitly requested that stage in the current turn.

## Final Response Contract

After all file sections, output one short Chinese completion sentence followed by a trailing `## fpga-architecture:quality_report` JSON block.

**Quality report example:**

```json
{
  "status": "completed | partial | needs_input | error",
  "title": "<task> 架构设计完成",
  "reason": "",
  "artifacts": [
    "doc/arch/interface_contract.yaml",
    "doc/arch/clock_reset_cdc.md",
    "doc/arch/module_partition.md",
    "doc/arch/connection_matrix.md",
    "rtl/top_skeleton.sv",
    "doc/arch/risks.md",
    "doc/arch/handoff_packet.md"
  ],
  "changed_files": [
    "doc/arch/interface_contract.yaml",
    "doc/arch/clock_reset_cdc.md",
    "doc/arch/module_partition.md",
    "doc/arch/connection_matrix.md",
    "rtl/top_skeleton.sv",
    "doc/arch/risks.md"
  ],
  "next_skill": "fpga-rtl-build"
}
```

Do not add markdown sections after the quality report.
